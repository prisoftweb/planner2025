import { Glossary } from "./Glossary"
import { UsrBack } from "./User"
import { Provider } from "./Providers"
import { Project } from "./Projects"
import { Report } from "./Reports"
import { Concept } from "./Concepts"

export interface ExpensesTable {
  id: string
  Responsable: {
    responsible: string,
    photo: string
  } 
  Proyecto: string 
  Informe: string 
  Descripcion: string 
  Proveedor: string 
  Estatus: string 
  Fecha: string 
  // Importe: string
  Importe: number
  ImporteMoneda: string
  condition: string,
  archivos: string[],
  costcenter: string,
  // vat: string,
  vat: number,
  vatMoneda: string
  // discount: string,
  discount: number,
  discountMoneda: string
  // total: string
  total: number
  totalMoneda: string
  taxFolio: string
  color: string
  darktext: boolean
  isCfdisRelations: boolean
}

// export interface Expense {
//   cost: Cost
//   _id: string
//   folio: string
//   taxfolio: string
//   description: string
//   date: string
//   taxapply: boolean
//   ispaid: boolean
//   category: Glossary
//   typeCFDI: Glossary
//   user: UsrBack
//   provider: Provider
//   costocenter:(string | CostCenter)
//   project: Project
//   status: boolean
//   condition: Condition[]
//   files: File[]
//   total: number
//   __v: number
//   id: string
//   report: Report
//   isticket: boolean
//   iscard: boolean
// }

export interface Expense {
  _id: string
  folio: string
  taxfolio: string
  description: string
  date: string
  taxapply: boolean
  isticket: boolean
  ispaid: boolean
  cost: Cost
  user: UsrBack
  project: Project
  report: Report
  provider: Provider
  costocenter: Costocenter
  typeCFDI: Glossary
  category: Glossary
  estatus: Glossary
  status: boolean
  iscard: boolean
  files: File[]
  expiredDate?: string
  daysExpired?: number
  code?:string
  isCfdisRelations?:boolean
}

export interface OneExpense {
  _id: string
  folio: string
  taxfolio: string
  description: string
  date: string
  taxapply: boolean
  isticket: boolean
  ispaid: boolean
  cost: Cost
  user: UsrBack
  project: Project
  report: Report
  provider: Provider
  costocenter: OneCostocenter
  typeCFDI: Glossary
  category: Glossary
  estatus: Glossary
  status: boolean
  iscard: boolean
  files: File[]
  isadvancesToSuppliers: boolean
  advancesToSuppliers?: {
    currentbalance: number
    percentadvance: number
    user: string
    notes: string[]
    advanceInvoicesCfdis: {
      invoiceUUID: string
      applicationUUID: string
      date: string
      _id: string
    }[]
  }
}

export interface OneCategory {
  _id: string
  name: string
  code: number
  categorys: ListCategory[]
  status: boolean
  id: string
}

export interface ListCategory {
  concept: Concept
  id: any
}

export interface Costocenter {
  _id: string
  category: string
  concept: Concept
}

export interface OneCostocenter {
  _id: string
  category: OneCategory
  concept: Concept
}

export interface File {
  file: string
  types: string
  _id: string
  id: string
}

export interface Condition {
  glossary: Glossary
  date: string
  user: string
  status: boolean
  _id: string
  id: string
}

export interface Vat {
  _id: string
  base: number
  value: number
  amount: number
  type: string
  status: boolean
  __v: number
  id: string
}

export interface Cost {
  subtotal: number
  discount: number
  iva: number
  vat: Vat
  vatvalue: number
  total: number
  exempttax: number
}

export interface ICostWithoutCode {
  _id: string
  cost: {
    subtotal: number
    iva: number
    total: number
    discount: number
    exempttax: any
  }
  provider: {
    _id: string
    name: string
  }
  project: {
    _id: string
    title: string
  }
  folio: string
  description: string
  date: string
  estatus: {
    _id: string
    name: string
    color: string
    darktext?: boolean
  }
  status: boolean
}

// export interface ICostRelAdvance {
//   _id: string
//   folio: string
//   taxfolio: string
//   description: string
//   date: string
//   taxapply: boolean
//   isticket: boolean
//   ispaid: boolean
//   iscard: boolean
//   cost: {
//     subtotal: number
//     iva: number
//     total: number
//     discount: number
//     exempttax: number
//   }
//   user: {
//     _id: string
//     name: string
//     photo: string
//   }
//   project: {
//     _id: string
//     title: string
//   }
//   report: {
//     _id: string
//     name: string
//   }
//   provider: {
//     _id: string
//     name: string
//   }
//   costocenter: {
//     _id: string
//     category: string
//     concept: {
//       _id: string
//       name: string
//     }
//   }
//   typeCFDI: {
//     _id: string
//     name: string
//   }
//   category: {
//     _id: string
//     name: string
//   }
//   files: {
//     file: string
//     types: string
//     _id: string
//   }[]
//   cfdisRelations: {
//     relatedUUIDs: string[]
//     typeUUID: string
//   }
//   estatus: {
//     _id: string
//     name: string
//     color: string
//     darktext?:boolean
//   }
//   status: boolean
// }

export interface ICostRelAdvanceInv {
  invoiceUUID: {
    _id: string
    folio: string
    taxfolio: string
    description: string
    date: string
    taxapply: boolean
    isticket: boolean
    ispaid: boolean
    iscard: boolean
    isadvancesToSuppliers: boolean
    cost: {
      subtotal: number
      iva: number
      total: number
      discount: number
      exempttax: any
    }
    user: {
      _id: string
      name: string
      photo: string
    }
    project: {
      _id: string
      title: string
    }
    report: {
      _id: string
      name: string
    }
    provider: {
      _id: string
      name: string
    }
    costocenter: {
      _id: string
      category: string
      concept: {
        _id: string
        name: string
      }
    }
    typeCFDI: {
      _id: string
      name: string
    }
    category: {
      _id: string
      name: string
    }
    files: {
      file: string
      types: string
      _id: string
    }[]
    isCfdisRelations: boolean
      cfdisRelations: {
      relatedUUIDs: string[]
      typeUUID: string
    }
    estatus: {
      _id: string
      name: string
      color: string
    }
    status: boolean
  }
  applicationUUID: {
    _id: string
    folio: string
    taxfolio: string
    description: string
    date: string
    taxapply: boolean
    isticket: boolean
    ispaid: boolean
    iscard: boolean
    isadvancesToSuppliers: boolean
    cost: {
      subtotal: number
      iva: number
      total: number
      discount: number
      exempttax: any
    }
    user: {
      _id: string
      name: string
      photo: string
    }
    project: {
      _id: string
      title: string
    }
    report: {
      _id: string
      name: string
    }
    provider: {
      _id: string
      name: string
    }
    costocenter: {
      _id: string
      category: string
      concept: {
        _id: string
        name: string
      }
    }
    typeCFDI: {
      _id: string
      name: string
    }
    category: {
      _id: string
      name: string
    }
    files: {
      file: string
      types: string
      _id: string
    }[]
    isCfdisRelations: boolean
    cfdisRelations: {
      relatedUUIDs: string[]
      typeUUID: string
    }
    estatus: {
      _id: string
      name: string
      color: string
    }
    status: boolean
  }[]
}

export interface ICostRelAdvanceTable{
  id:string
  user: {
    _id: string
    name: string
    photo: string
  }
  files: {
    file: string
    types: string
    _id: string
  }[]
  project: string
  folio:string
  description:string
  date:string
  cost: {
    subtotal: number
    iva: number
    total: number
    discount: number
    exempttax: any
  }
  isinvoiceUUID: boolean
}