import NavClientsStepper from "./NavClientsStepper"
import Input from "../Input"
import Label from "../Label"
import { useState, useRef } from "react"
import UploadImage from "../UploadImage"
import { useRegFormContext } from "./StepperClientProvider";
import Button from "../Button"
import { showToastMessage, showToastMessageError } from "../Alert"
import SaveClient from "@/app/functions/SaveClient"
import { SaveClientLogo } from "@/app/functions/SaveClient"
import { useClientStore } from "@/app/store/clientStore"

export default function ExtraDataStepper({token, company}: {token:string, company:string}){
  
  const [state, dispatch] = useRegFormContext();
  const [page, setPage] = useState('');
  const [file, setFile] = useState('');
  const refRequest = useRef(true);

  const {pushClient} = useClientStore();

  const onClickSave = async () => {
    refRequest.current = false;
    if(file){
      const data = new FormData();
      if(state.databasic){
        data.append('name', state.databasic.name);
        data.append('tradename', state.databasic.tradename);
        data.append('taxregime', state.databasic.taxregime);
        if(state.databasic.email){
          data.append('email', state.databasic.email);
        }
        if(state.databasic.capitalregime){
          data.append('capitalregime', state.databasic.capitalregime);
        }
        data.append('rfc', state.databasic.rfc);
        data.append('source', state.databasic.source);
        data.append('regime', state.databasic.regime);
        if(state.databasic.user){
          data.append('user', state.databasic.user);
        }
      }

      let stret='', cp='', municipy='', country='', stateS='', community='';
      if(state.address){
        stret = state.address.stret? state.address.stret: '';
        cp = state.address.cp? state.address.cp: '';
        municipy = state.address.municipy? state.address.municipy: '';
        country = state.address.country? state.address.country: '';
        community = state.address.community? state.address.community: '';
        stateS = state.address.stateS? state.address.stateS: '';
      }

      const location = {
        community,
        country,
        // cp: cp,
        cp: parseInt(cp),
        municipy,
        state: stateS,
        stret
      }

      data.append('logo', file);
      if(page && page!==''){
        data.append('link', page);
      }

      try {
        const res = await SaveClientLogo(data, token, location, 
              state.databasic.tags? state.databasic.tags: [], state.contacts? state.contacts: [],
              state.databasic.phone? state.databasic.phone: '');
        if(res.status){
          refRequest.current = true;
          showToastMessage(res.message);
          if(res.client) pushClient(res.client);
        }else{
          refRequest.current = true;
          showToastMessageError(res.message);
        }
      } catch (error) {
        refRequest.current = true;
        showToastMessageError('Error al crear cliente!!');
      }

    }else{
      let name='', tradename='', email='', rfc='', source='', phone='',tags=[], user='', regime='', taxregime='', capitalregime='';
      if(state.databasic){
        name=state.databasic.name? state.databasic.name : '';
        tradename=state.databasic.tradename? state.databasic.tradename : '';
        taxregime=state.databasic.taxregime? state.databasic.taxregime : '';
        capitalregime=state.databasic.capitalregime? state.databasic.capitalregime : '';
        email=state.databasic.email? state.databasic.email : '';
        rfc=state.databasic.rfc? state.databasic.rfc : '';
        phone=state.databasic.phone? state.databasic.phone : '';
        source=state.databasic.source? state.databasic.source : '';
        tags=state.databasic.tags? state.databasic.tags : '';
        user=state.databasic.user? state.databasic.user : '';
        regime=state.databasic.regime? state.databasic.regime : '';
      }

      let contact = [];
      if(state.contacts){
        contact = state.contacts;
      }

      let stret='', cp='', municipy='', country='', stateS='', community='';
      if(state.address){
        stret = state.address.stret? state.address.stret: '';
        cp = state.address.cp? state.address.cp: '';
        municipy = state.address.municipy? state.address.municipy: '';
        country = state.address.country? state.address.country: '';
        community = state.address.community? state.address.community: '';
        stateS = state.address.stateS? state.address.stateS: '';
      }

      const data = {
        name, 
        tradename, 
        email, 
        rfc, 
        taxregime, 
        capitalregime,
        phone, 
        source,
        tags, 
        user,
        company,
        link:page,
        regime,
        location: {
          stret,
          // cp,
          cp:parseInt(cp),
          municipy, 
          country,
          community,
          state:stateS,
        },
        contact
      }

      try {
        const res = await SaveClient(data, token);
        if(res.status){
          refRequest.current = true;
          showToastMessage(res.message);
          if(res.client) pushClient(res.client);
        }else{
          refRequest.current = true;
          showToastMessageError(res.message);
        }
      } catch (error) {
        refRequest.current = true;
        showToastMessageError('Error al crear cliente!!');
      }
    }
  }

  const onClickNext = () => {
    
    type Page = {
      link: string,
      photo?: any,
    }

    const data: Page = {
      photo: file,
      link: page,
    }
    
    if(!file){
      delete data.photo;
    }

    dispatch({ type: 'SET_EXTRA_DATA', data: data });
    dispatch({type: 'INDEX_STEPPER', data: 2})
  }

  return(
    <>
      <div className="w-full">
        <div className="my-5">
          <NavClientsStepper index={1} />
        </div>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <Label>Pagina</Label>
            <Input type="text" value={page} onChange={(e) => setPage(e.target.value)} 
              autoFocus
            />
          </div>
          <div>
            <Label>Logotipo</Label>
            <UploadImage setFile={setFile} />
          </div>
        </div>
        <div className="flex justify-center mt-8 space-x-5">
          <Button 
            onClick={() => {
              if(refRequest.current){
                onClickSave();
              }
              else{
                showToastMessageError('Ya hay una peticion en proceso..!');
              }
            }} type="button">Guardar</Button>
          <button type="button" onClick={onClickNext}
            className="border w-36 h-9 bg-white font-normal text-sm text-slate-900 border-slate-900 rounded-xl
            hover:bg-slate-200"
          >
            Siguiente
          </button>
        </div>
      </div>
    </>
  )
}