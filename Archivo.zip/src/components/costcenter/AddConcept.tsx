import { useState } from 'react'
import { PlusCircleIcon, CheckCircleIcon, TrashIcon } from "@heroicons/react/24/solid";
import Label from '../Label';
import Input from '../Input';

type Props={ 
  pushElement:Function, 
  bandPlus:boolean, 
  DeleteElement:Function, 
  index:number, 
  updateCount: Function
}

export default function AddConcept({bandPlus, DeleteElement, index, 
  pushElement, updateCount}: Props ){
  
  const [saved, setSaved] = useState(false);
  const [add, setAdd] = useState(false);
  const [ok, setOk] = useState<boolean>(true);
  const [message, setMessage] = useState<string>('');
  const [concept, setConcept] = useState<string>('');
  const [account, setAccount] = useState<string>('');

  const onChangeConcept = (value:string) => {
    setConcept(value);
  }

  const onChangeAccount = (value:string) => {
    setAccount(value.replace(/[$,]/g, ""));
  }
  
  const onPlus = () =>{
    if(concept !== '' && account !== '' && saved){
      setAdd(true);
      updateCount();
    }else{
      setMessage('* Guarde el concepto primero!!');
      setOk(false);
      setTimeout(() => {
        setOk(true);
      }, 2000);
    }
  }

  const save = () => {
    if(concept !== '' && account !== ''){
      setSaved(true);
      pushElement(concept, account);
    }else{
      setMessage('* Todos los campos son obligatorios!!');
      setOk(false);
      setTimeout(() => {
        setOk(true);
      }, 2000);
    }
  }

  const deleteElement = () => {
    DeleteElement(index);
  }

  return(
    <>
      <div className='flex items-center mt-2 flex-wrap gap-x-1 gap-y-1'>
        <div>
          <Label htmlFor="concept"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Nombre</p></Label>
          <Input type='text' name='concept' 
            onChange={(e) => onChangeConcept(e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="account"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Cuenta</p></Label>
          <Input type='text' name='account' 
            onChange={(e) => onChangeAccount(e.target.value)}
          />
        </div>
        <div>
          <Label ><p>&nbsp;</p></Label>
          <CheckCircleIcon width={30} height={30} className={`text-red-500 cursor-pointer ${saved? 'invisible': ''}`} onClick={save} />
        </div>
        <div>
          <Label htmlFor=""><p>&nbsp;</p></Label>
          <PlusCircleIcon width={30} height={30} className={`text-green-500 cursor-pointer ${add? 'invisible': ''} ${bandPlus? '': 'invisible'}`} onClick={onPlus} />
        </div>
        <div>
          <Label htmlFor=""><p>&nbsp;</p></Label>
          <TrashIcon width={30} height={30} onClick={deleteElement} className={`text-red-500 cursor-pointer ${saved? '': 'invisible'}`} />
        </div>
      </div>
      { !ok && (<p className='text-red-500 text-xs'>{message}</p>)  }
    </>
  )
}