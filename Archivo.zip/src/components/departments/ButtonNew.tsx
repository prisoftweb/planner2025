'use client'
import Button from "../Button"
import { useState } from "react";
import NewDepartment from "./NewDepartment";
import { Options } from "@/interfaces/Common";
import { DepartmentTable } from "@/interfaces/Departments";
import ContainerSideNav from "../ContainerSideNav";

type ButtonNewProps = {
  token:string, 
  optionsCompany:Options[], 
  dept:(DepartmentTable | string),
  company:string
}

export default function ButtonNew({token, optionsCompany, dept, company}: ButtonNewProps){
  const [newCompany, setNewCompany] = useState<boolean>(false);
  
  return(
    <>
      <Button type="button" onClick={() => setNewCompany(true)}>Nuevo</Button>
      <ContainerSideNav width="w-full max-w-sm" open={newCompany}>
        <NewDepartment showForm={setNewCompany} token={token} 
                      OptionsCompany={optionsCompany} dept={dept} company={company} />
      </ContainerSideNav>
    </>
  )
}