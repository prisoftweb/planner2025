import Label from "@/components/Label";
import Input from "@/components/Input";
import CurrencyInput from "react-currency-input-field";
import Button from "@/components/Button";
import { useState } from "react";
import { PriceConcept, IConceptEstimateMin } from "@/interfaces/Estimate";
import { CurrencyFormatter } from "@/app/functions/Globals";

type Props = { 
  conceptSelected: IConceptEstimateMin, 
  previousStep: Function, 
  price: PriceConcept| undefined, 
  user:string, 
  updateConcepts: Function, 
  showForm:Function
}

export default function DataConceptStepperComponent({previousStep, price, conceptSelected, 
  user, updateConcepts, showForm}: Props) {

  const [quantity, setQuantity] = useState<string>('0');
  const [pu, setPu] = useState<string>('0');
  
  const [bandQuantity, setBandQuantity] = useState<boolean>(false);
  const [bandPU, setBandPU] = useState<boolean>(false);

  const validationData = () => {
    let validation = true;
    if(!quantity || quantity===''){
      setBandQuantity(true);
      validation = false;
    }else{
      setBandQuantity(false);
    }
    if(!pu || pu===''){
      setBandPU(true);
      validation = false;
    }else{
      setBandPU(false);
    }
    
    if(validation){
      saveData();
    }
  }

  const saveData = async () => {
    const data = {
      conceptEstimate: conceptSelected,
      priceConcepEstimate: {
          cost: price?.cost,
          date: price?.date,            
          user: price?.user._id
      },
      quantity: Number(quantity),
      // amount: Number(pu.replace(/[$,]/g, "")),
      amount: (price?.cost || 0),
      date: new Date(),
      user: user
    }
    console.log('quantity => ', quantity);
    console.log('pu => ', pu);
    console.log('data => ', data);
    console.log('cost => ', price?.cost);
    updateConcepts(data);
    showForm(false);
  }

  const calculatedPU = (valueQuantity:string) => {
    const res = (price?.cost || 0) * Number(valueQuantity.replace(/[$,]/g, ""));
    setPu(res.toString());
  }

  return (
    <>
      <div>
        <div className="flex justify-between items-end p-2 bg-slate-100 border border-slate-500 rounded-t-lg">
          <p className="text-slate-700">{conceptSelected.name}</p>
          <p className="text-slate-700">{conceptSelected.code}</p>
        </div>
        <div className="border border-slate-500 p-2 text-xs text-slate-500">
          <p>{conceptSelected.description}</p>
        </div>
      </div>

      <div className="border border-slate-500 rounded-lg grid grid-cols-2">
        <div className="flex items-center justify-around gap-x-2">
          <img alt="responsable" src={ (price?.user?.photo? price.user.photo: '/img/users/default.jpg') || '/img/users/default.jpg'}
            className="relative inline-block h-12 w-12 !rounded-full  object-cover object-center" />
          <p className="text-slate-600">{price?.user?.name || 'nombre'}</p>
        </div>
        <div className="border border-slate-500 flex w-full h-full justify-center items-center">
          {CurrencyFormatter({
            currency: 'MXN',
            value: price?.cost || 0
          })}
        </div>
      </div>

      <div className="p-2">
        <div className="grid grid-cols-2 gap-x-1">
          <div className="">
            <Label htmlFor="quantity"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Cantidad</p></Label>
            <Input type="text" name="quantity" 
              value={quantity}
              onChange={(e) => {
                setQuantity(e.target.value);
                calculatedPU(e.target.value);
              }}
            />
            {bandQuantity && (
              <p className="text-red-500">La cantidad es obligatoria!!!</p>
            )}
          </div>
          <div>
            <Label htmlFor="pu"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Importe</p></Label>
            <CurrencyInput
              id="pu"
              name="pu"
              className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white
                focus:border-slate-700 outline-0"
              value={pu}
              decimalsLimit={2}
              prefix="$"
              disabled
            />
            {bandPU && (
              <p className="text-red-500">El importe es obligatorio!!!</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-2 gap-x-2">
        <button className="text-black font-normal text-sm bg-white 
          rounded-xl w-36 h-9 py-2 hover:bg-slate-200 border border-black"
          onClick={() => previousStep(1)}>Atras</button>
        <Button type="button" onClick={validationData}>Guardar</Button>
      </div>
    </>
  )
}
