'use client'
import Label from "../Label"
import { XMarkIcon } from "@heroicons/react/24/solid"
import { useState, useEffect } from "react"
import SelectMultipleReact from "../SelectMultipleReact"
import { Options } from "@/interfaces/Common";
import Calendar, { DateObject } from "react-multi-date-picker";
import MultiRangeSlider from "multi-range-slider-react";
import { CurrencyFormatter } from "@/app/functions/Globals";
import { GiSettingsKnobs } from "react-icons/gi"
import { getCatalogsByNameAndCondition } from "@/app/api/routeCatalogs"
import TooltipCloseIcon from "../tooltipIcons/TooltipCloseIcon"

type Props = {
  showForm:(value: boolean) => void, 
  FilterData:Function, 
  maxAmount:number, 
  minAmount:number, 
  token: string, 
  showPaidValidation?: boolean
}

export default function FilteringExpensesProvider({showForm, FilterData, maxAmount, minAmount, 
  token, showPaidValidation=true }: Props){

  const [conditionsSel, setConditionsSel] = useState<string[]>(['all']);
  const [heightPage, setHeightPage] = useState<number>(900);

  const [conditions, setConditions] = useState<Options[]>([]);  
  const [firstDate, setFirstDate] = useState<Date>(new Date('2024-03-11'));
  const [secondDate, setSecondDate] = useState<Date>(new Date('2024-07-11'));

  const [isPaid, setIsPaid] = useState<number>(1);

  const [values, setValues] = useState([
    new DateObject().setDay(4).subtract(1, "month"),
    new DateObject().setDay(4).add(1, "month")
  ]);

  const handleValues = (dateValues: DateObject[]) => {
    setValues(dateValues);
    if(dateValues.length > 1){
      setFirstDate(new Date(dateValues[0].year, dateValues[0].month.number - 1, dateValues[0].day));
      setSecondDate(new Date(dateValues[1].year, dateValues[1].month.number - 1, dateValues[1].day));
      filterfunction(conditionsSel, minValue, maxValue, 
        new Date(dateValues[0].year, dateValues[0].month.number - 1, dateValues[0].day), 
        new Date(dateValues[1].year, dateValues[1].month.number - 1, dateValues[1].day), isPaid);
    }else{
      if(values.length > 0){
        setFirstDate(new Date(values[0].year, values[0].month.number - 1, values[0].day));
      }
    }
  }

  useEffect(() => {
    const fetchApis = async () => {
      let optConditions: Options[] = [];
      try {
        optConditions = await getCatalogsByNameAndCondition(token, 'cost');
        if(typeof(optConditions)==='string') return <h1 className="text-red-500 text-center text-lg">{optConditions}</h1>
      } catch (error) {
        return <h1>Error al consultar catalogos!!</h1>
      }

      setConditions(optConditions);
    }

    fetchApis();
  }, []);

  const [minValue, set_minValue] = useState(minAmount);
  const [maxValue, set_maxValue] = useState(maxAmount);

  const handleInput = (e:any) => {
    set_minValue(e.minValue);
    set_maxValue(e.maxValue);
  };

  const handleResize = () => {
    setHeightPage(Math.max(
      document.body.scrollHeight, document.documentElement.scrollHeight,
      document.body.offsetHeight, document.documentElement.offsetHeight,
      document.body.clientHeight, document.documentElement.clientHeight
    ));
  }

  const handleConditions = (value: string[]) => {
    setConditionsSel(value);
    filterfunction(value, minValue, maxValue, firstDate, secondDate, isPaid);
  }

  const handlePaid = (value: number) => {
    setIsPaid(value);
    filterfunction(conditionsSel, minValue, maxValue, firstDate, secondDate, value);
  }

  useEffect(() => {
    window.addEventListener("resize", handleResize, false);
    setHeightPage(Math.max(
      document.body.scrollHeight, document.documentElement.scrollHeight,
      document.body.offsetHeight, document.documentElement.offsetHeight,
      document.body.clientHeight, document.documentElement.clientHeight
    ));
    return () => window.removeEventListener('scroll', handleResize);
  }, []);

  useEffect(() => {
    FilterData(conditionsSel, minValue, maxValue, 
      firstDate?.getTime(), secondDate?.getTime(), isPaid);
  }, [ minValue, maxValue]);

  const filterfunction = (condSel:string[], minVal:number, maxVal:number, dateini:Date, 
    dateend:Date, isP:number ) => {
    FilterData(condSel, minVal, maxVal, dateini?.getTime(), dateend?.getTime(), isP);
  }

  const allArray = [{
    label: 'TODOS',
    value: 'all'
  }];

  if(conditions.length === 0){
    return <></>
  }

  return(
    <>
      {/* <div className="fixed inset-0 bg-black bg-opacity-40  z-40"> */}
        {/* top-16 */}
        <form className="z-10 w-full max-w-md absolute bg-white space-y-5 px-2 py-2 sm:py-5 sm:px-7 right-0"
          style={{height: `${heightPage}px`}}
        >
          <div className="flex justify-between p-2 rounded-md" style={{backgroundColor:'#F8FAFC', border:'0.5px solid #D3D3D3'}}>
            <div className="flex mt-2 items-center">
              <GiSettingsKnobs className="w-8 h-8 text-slate-600" />
              <div className="ml-3">
                <p className="text-xl">Filtrar gasto</p>
                <p className="text-gray-500 text-sm">Filtra gastos por diferentes caracteristicas</p>
              </div>
            </div>
            <TooltipCloseIcon handleClose={showForm} />
          </div>

          {showPaidValidation && (
            <div className="flex justify-end px-5 items-center">
              <p className="text-gray-500 text-sm after:content-['*'] after:ml-0.5 after:text-red-500">Pagado?</p>
              <div>
                <div className="inline-flex rounded-md shadow-sm mx-2">
                <button type="button" className={`px-3 py-1 text-sm border border-blue-400 rounded-md 
                            ${isPaid === 1? 'bg-blue-500 text-white': ''}`}
                    onClick={() => handlePaid(1)}
                  >
                    Ambos
                  </button>
                  <button type="button" className={`px-3 py-1 text-sm border border-green-400 rounded-md 
                            ${isPaid===2? 'bg-green-500 text-white': ''}`}
                    onClick={() => handlePaid(2)}
                  >
                    Pagado
                  </button>
                  <button type="button" className={`px-3 py-1 text-sm border border-red-400 rounded-md 
                            ${isPaid===3? 'bg-red-500 text-white': ''}`}
                    onClick={() => handlePaid(3)}
                  >
                    No Pagado
                  </button>
                </div>
              </div>
            </div>
          )}
          
          <div className="">
            <Label htmlFor="status"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Status</p></Label>
            <SelectMultipleReact index={0} opts={allArray.concat(conditions)} setValue={handleConditions} />
          </div>
          <div className="pt-0">
            <Label htmlFor="amount"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Monto</p></Label>
            <MultiRangeSlider
              min={minAmount}
              max={maxAmount}
              step={5}
              minValue={minValue}
              maxValue={maxValue}
              onInput={(e) => {
                handleInput(e);
              }}
              style={{border: 'none', boxShadow: 'none', padding: '15px 10px', 
                  backgroundColor: 'white', 'zIndex': '0'}}
              label='false'
              ruler='false'
              barLeftColor='red'
              barInnerColor='blue'
              barRightColor='green'
              thumbLeftColor='lime'
              thumbRightColor='lime'
            />
            <div className="flex justify-between">
              <p>{CurrencyFormatter({
                    currency: "MXN",
                    value: minValue
                  })}</p>
              <p>{CurrencyFormatter({
                    currency: "MXN",
                    value: maxValue
                  })}</p>
            </div>
          </div>
          <div>
            <Label htmlFor="date"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Rango de fechas</p></Label>
            <Calendar
              className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-slate-100 
                focus:border-slate-700 outline-0"
              value={values}
              onChange={(e: any) => {
                handleValues(e);
              }}
              range
              numberOfMonths={2}
              showOtherDays
              style={{'padding': '10px', 'marginTop': '5px', 'borderRadius': '5px', 
                'height': '35px', 'width': '330px'}}
            /> 
          </div>
        </form>
      {/* </div> */}
    </>
  )
}