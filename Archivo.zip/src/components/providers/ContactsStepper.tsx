import { useState, useRef } from "react";
import { useRegFormContext } from "./StepperProvider";
import SaveProvider from "@/app/functions/SaveProvider";
import { showToastMessage, showToastMessageError } from "../Alert";
import FormContact from "./FormContact";
import BasicBarStepper from "./BasicBarStepper";
import { useProviderStore } from "@/app/store/providerStore";

export default function ContactsStepper({id, token, user, company}: 
  {id:string, token:string, user: string, company:string}){
  
  const [state, dispatch] = useRegFormContext();
  const [contacts, setContacts] = useState<string[]>([]);
  const refRequest = useRef(true);
 
  const {providerStore, updateProviderStore, updateHaveNewProvider} = useProviderStore();
  
  const onClickSave = async () => {
    if(refRequest.current){
      refRequest.current = false;
      const {name, rfc, suppliercredit, tradename, type} = state.databasic;
      let tradeline = {};
      let cat;

      if(suppliercredit){
        const {creditdays, creditlimit, currentbalance, percentoverduedebt, category} = state.creditline;
        tradeline = {
          creditdays: parseInt(creditdays),
          creditlimit: parseInt(creditlimit),
          currentbalance: parseInt(currentbalance),
          percentoverduedebt: parseInt(percentoverduedebt)
        }
        cat=category;
      }
      
      try {
        if(name && rfc && tradename){
          
          const data: any = {
            name,
            rfc,
            tradename,
            suppliercredit,
            tradeline,
            contact: contacts,
            user: user,
            type,
            category:cat,
            company,
            condition: [{
              glossary: '663d2fe61d1c43ae98d77bc3',
              user
            },
              ...(suppliercredit
                ? [{
                    glossary: "6746442a734d5ab78ab98ddd",
                    user
                  }]
                : [])],
          }

          // console.log('supplier credit => ', suppliercredit);
          // console.log('data => ', JSON.stringify(data));
          const res = await SaveProvider(data, token);
          if(res.status){
            // console.log('res provider', res.prov);
            refRequest.current = true;
            showToastMessage(res.message);
            updateProviderStore([...providerStore, res.prov]);
            updateHaveNewProvider(true);
            dispatch({ type: 'SET_BASIC_DATA', data: null });
            dispatch({ type: 'SET_CREDIT_DATA', data: null });
            dispatch({ type: 'SET_CONTACTS', data: [] });
            dispatch({type: 'INDEX_STEPPER', data: 0})
          }else{
            refRequest.current = true;
            showToastMessageError(res.message);
          }
        }else{
          refRequest.current = true;
          showToastMessageError('Nombre y RFC son obligatorios');
        }
      } catch (error) {
        refRequest.current = true;
        showToastMessageError('Error al crear proveedor!!');
      }
    }else{
      showToastMessageError('Ya hay una solicitud en proceso..!!!');
    }
  }

  const newContact = (newContact:string) => {
    setContacts((oldContacts) => [...oldContacts, newContact])
    if(state.contacts){
      dispatch({ type: 'SET_CONTACTS', data: [...state.contacts, newContact] });
    }else{
      dispatch({ type: 'SET_CONTACTS', data: [newContact] });
    }
  }
  
  const updateContact = () => {}

  return(
    <>
      <div className="w-full">
        <div className="mx-5">
          <BasicBarStepper index={2} />
        </div>
        <FormContact addNewContact={newContact} token={token} contact={''} 
            updateContact={updateContact} company={company} >
          <button type="button" 
            onClick={onClickSave}
            className="border w-36 h-9 bg-white font-normal text-sm text-slate-900 border-slate-900 rounded-xl
           hover:bg-slate-200">
            Guardar
          </button>
        </FormContact>
      </div>
    </>
  )
}