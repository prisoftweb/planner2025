'use client'
import Button from "../Button"
import { useState } from "react";
import NewStatus from "./NewStatus";
import { Options } from "@/interfaces/Common";
import { InsertCategoryInCatalog, InsertConditionInCatalog, InsertTypeInCatalog } from "@/app/api/routeCatalogs";
import { FireIcon, TagIcon, Battery50Icon } from "@heroicons/react/24/solid";
import {Tooltip} from "@nextui-org/react";
import ContainerSideNav from "../ContainerSideNav";
import { propsTooltip } from "@/libs/animations";

type Props = {
  token:string, 
  catalogOptions:Options[], 
  glosariesOptions:Options[], 
  descGlossaries:Options[], 
  opt:number}

export default function ButtonNew({token, catalogOptions, descGlossaries, glosariesOptions, opt}:
  Props){
  const [newStatus, setNewStatus] = useState<boolean>(false);
  const [newType, setNewType] = useState<boolean>(false);
  const [newCategory, setNewCategory] = useState<boolean>(false);

  let button;

  switch(opt){
    case 1: 
      button = (
        <>
          <div className=" hidden sm:block"><Button type="button" onClick={() => setNewType(true)}>Nuevo tipo</Button></div>
          <Tooltip closeDelay={0} delay={100} motionProps={propsTooltip} 
            className="text-blue-500 bg-white rounded-md border border-slate-400" content='Estatus'
            placement="right"  
          >
              <FireIcon className="w-10 h-10 sm:hidden cursor-pointer" onClick={() => setNewType(true)} />
          </Tooltip>
        </>
      )
    break;
    case 2: 
      button = (
        <>
          <div className=" hidden sm:block"><Button type="button" onClick={() => setNewCategory(true)}>Nueva categoria</Button></div>
          <TagIcon className="w-10 h-10 sm:hidden cursor-pointer" onClick={() => setNewCategory(true)} />
        </>
      )
    break;
    case 3: 
      button = (
        <>
          <div className=" hidden sm:block"><Button type="button" onClick={() => setNewStatus(true)}>Nuevo status</Button></div>
          <Battery50Icon className="w-10 h-10 sm:hidden cursor-pointer" onClick={() => setNewStatus(true)} />
        </>
      )
    break;
  }

  return(
    <>
      {button}
      {/* {newType && (
        <ContainerSideNav width="w-full max-w-sm">
          <NewStatus showForm={setNewType} token={token} opt={opt}
                  catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
                  glosariesOptions={glosariesOptions} insertFunction={InsertTypeInCatalog} />
        </ContainerSideNav>
      )}
      {newCategory && (
        <ContainerSideNav width="w-full max-w-sm">
          <NewStatus showForm={setNewCategory} token={token} opt={opt}
                  catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
                  glosariesOptions={glosariesOptions} insertFunction={InsertCategoryInCatalog} />
        </ContainerSideNav>
      )}
      {newStatus && (
        <div className="fixed inset-0 bg-black bg-opacity-40  z-40">
          <ContainerSideNav width="w-full max-w-sm">
            <NewStatus showForm={setNewStatus} token={token} opt={opt}
                  catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
                  glosariesOptions={glosariesOptions} insertFunction={InsertConditionInCatalog} />
          </ContainerSideNav>
        </div>
      )} */}
      <ContainerSideNav width="w-full max-w-sm" open={newType} >
        <NewStatus showForm={setNewType} token={token} opt={opt}
                catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
                glosariesOptions={glosariesOptions} insertFunction={InsertTypeInCatalog} />
      </ContainerSideNav>
      <ContainerSideNav width="w-full max-w-sm" open={newCategory} >
        <NewStatus showForm={setNewCategory} token={token} opt={opt}
                catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
                glosariesOptions={glosariesOptions} insertFunction={InsertCategoryInCatalog} />
      </ContainerSideNav>
      <ContainerSideNav width="w-full max-w-sm" open={newStatus} >
        <NewStatus showForm={setNewStatus} token={token} opt={opt}
              catalogOptions={catalogOptions} descGlossaries={descGlossaries} 
              glosariesOptions={glosariesOptions} insertFunction={InsertConditionInCatalog} />
      </ContainerSideNav>
    </>
  )
}