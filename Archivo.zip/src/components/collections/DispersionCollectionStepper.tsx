'use client'
import { useState, useEffect } from "react";
import Button from "@/components/Button";
import { showToastMessageError } from "@/components/Alert";
import { getUnpaidInvoices } from "@/app/api/routeInvoices";
import { IInvoiceMin } from "@/interfaces/Invoices";
import { CurrencyFormatter } from "@/app/functions/Globals";
import CurrencyInput from "react-currency-input-field";
import Label from "@/components/Label";
import HeaderForm from "../HeaderForm";

type TInvoiceStepper={
  folio: string,
  total: number,
  totalPending: number,
  previousAmount: number,
  id:string,
  project: {
    title:string,
    id:string
  },
  concepts: string
}

export default function DispersionCollectionStepper({token, user, NextStep, invoicesDisp, 
  saveCollection, updateAmount}: 
  {token:string, user:string, NextStep:Function, invoicesDisp:TInvoiceStepper[], 
    saveCollection:Function, updateAmount: Function}) {

  const [search, setSearch]=useState<string>('');
  const [invoices, setInvoices]=useState<TInvoiceStepper[]>([]);
  const [selected, setSelected]=useState<TInvoiceStepper>();
  const [amount, setAmount]=useState<string>('0');
  const [showAddDispersion, setShowAddDispersion]=useState<boolean>(false);

  useEffect(() => {
    const fetch = async() => {
      const res = await getUnpaidInvoices(token);
      if(typeof(res)==='string'){
        showToastMessageError('Error al obtener facturas!!!');
      }else{
        const resI=transformTypes(res);
        setInvoices(resI);
      }
    }
    fetch();
  }, []);

  const filteredInvoices = search==''? invoices: invoices?.filter((i) => i?.folio?.toString()?.includes(search));

  const addNewDispersion = () => {
    if(selected){
      const data: TInvoiceStepper = {
        id:selected?.id,
        folio: selected.folio,
        project: {
          id: selected.project.id,
          title: selected.project.title
        },
        total: Number(amount),
        totalPending: selected.totalPending,
        previousAmount: selected.previousAmount,
        concepts: selected.concepts
      }
      setAmount('0');
      const i = [...invoicesDisp, data];
      updateAmount(i);
      setShowAddDispersion(false);
    }else{
      showToastMessageError('Seleccione una factura primero!!!!');
    }
  }

  const view = showAddDispersion? 
    <>
      {Array.isArray(invoicesDisp) && invoicesDisp.map((inv) => (
        <div className="border border-slate-600 grid grid-cols-2 gap-x-2 gap-y-2 p-3" key={inv.id}>
          <p className="text-xs text-slate-400">Factura No. {inv?.folio}</p>
          <p className="text-xs text-slate-600">Monto de factura: {CurrencyFormatter({
            currency: 'MXN',
            value: invoices?.find((i) => i?.id===inv?.id)?.total || 0
          })}</p>
          <p className="text-xs text-slate-400">Proyecto: {inv?.project?.title}</p>
          <p className="text-xs text-slate-600">Monto abonado: {CurrencyFormatter({
            currency: 'MXN',
            value: inv?.total || 0
          })} </p>
        </div>
      ))}
      <div className="border border-slate-600 grid grid-cols-2 gap-x-2 gap-y-2 p-3">
        <p className="text-xs text-slate-400">Factura No. {selected?.folio}</p>
        <p className="text-xs text-slate-600">Monto de factura: {CurrencyFormatter({
          currency: 'MXN',
          value: selected?.total || 0
        })}</p>
        <p className="text-xs text-slate-400">Proyecto: {selected?.project?.title}</p>
        <p className="text-xs text-slate-600">Monto abonado: ? </p>
      </div>

      <div className="flex items-end gap-x-2 mt-3">
        <div>
          <Label>Cobrado / Abonado</Label>
          <CurrencyInput
            prefix="$"
            value={amount?.replace(/[$,]/g, "")}
            className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white 
                      focus:border-slate-700 outline-0"
            onChange={(e) => setAmount(e.target.value.replace(/[$,]/g, "") || '0')}
            autoFocus
          />
        </div>
        <div className="my-2">
          <Button
            onClick={addNewDispersion}
          >Agregar</Button>
        </div>
      </div>
    </>: (
    <>
      <div className="flex items-center gap-x-2">
        <div className="relative w-full p-2">
          <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
            <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
            </svg>
          </div>
          <input 
            type="search" 
            id="default-search"
            value={search}
            autoFocus
            onChange={(e) => setSearch(e.target.value)} 
            className="block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 
              rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500
              outline-0 outline-none 
              dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 
              dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder={'Buscar factura'} required ></input>
        </div>
      </div>
      <div className="relative flex flex-col text-gray-700 bg-white shadow-md w-full rounded-xl bg-clip-border">
        <nav className="flex w-full flex-col gap-1 p-2 font-sans text-base font-normal text-blue-gray-700 h-96
            overflow-scroll overflow-x-hidden" style={{scrollbarColor: '#ada8a8 white', scrollbarWidth: 'thin'}}>
          {Array.isArray(filteredInvoices) && filteredInvoices.map((invoice) => (
            <div role="button"
              key={invoice.id}
              className={`flex items-center justify-between w-full p-3 leading-tight transition-all rounded-lg 
                outline-none text-start hover:bg-blue-gray-50 hover:bg-opacity-80 hover:text-blue-gray-900 
                focus:bg-blue-gray-50 focus:bg-opacity-80 focus:text-blue-gray-900 active:bg-blue-gray-50 
                active:bg-opacity-80 active:text-blue-gray-900 border-b border-slate-300`}
              onClick={() => {
                setSelected(invoice);
                setShowAddDispersion(true);
              }}
            >
              <div className="flex items-center ">
                <div className="grid mr-4 place-items-center">
                  <img alt="responsable" src={ '/img/estimates/invoices.svg'}
                    className="relative inline-block h-12 w-12 !rounded-full  object-cover object-center" />
                </div>
                <div className={`w-full`}>
                  <div className="flex justify-between items-center">
                    <h6
                      className="block font-sans antialiased font-semibold leading-relaxed tracking-normal text-2xl text-blue-600">
                      {invoice.folio}
                    </h6>
                    <p className="text-slate-500 text-sm">{CurrencyFormatter({
                      currency: 'MXN',
                      value: invoice.total
                    })}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <h6
                      className="block font-sans antialiased font-semibold leading-relaxed tracking-normal text-green-600">
                      {invoice.project.title}
                    </h6>
                    <p className="text-slate-500 text-sm">{invoice.concepts}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}

        </nav>
      </div>

      <div className="mt-3">
        <HeaderForm img="/img/estimates/invoices.svg" 
              subtitle="Listado de facturas a las cuales se disperso el cobro" title="Facturas dispersadas" />
      </div>
      <div className="relative flex flex-col text-gray-700 bg-white shadow-md w-full rounded-xl bg-clip-border">
        <nav className="flex w-full flex-col gap-1 p-2 font-sans text-base font-normal text-blue-gray-700 h-96
            overflow-scroll overflow-x-hidden" style={{scrollbarColor: '#ada8a8 white', scrollbarWidth: 'thin'}}>
          {invoicesDisp.map((invoice) => (
            <div role="button"
              key={invoice.id}
              className={`flex items-center justify-between w-full p-3 leading-tight transition-all rounded-lg 
                outline-none text-start hover:bg-blue-gray-50 hover:bg-opacity-80 hover:text-blue-gray-900 
                focus:bg-blue-gray-50 focus:bg-opacity-80 focus:text-blue-gray-900 active:bg-blue-gray-50 
                active:bg-opacity-80 active:text-blue-gray-900`}
            >
              <div className="flex items-center ">
                <div className={`w-full`}>
                  <div className="flex justify-between items-center text-blue-100 border border-slate-500 rounded-t-md">
                    <h6
                      className="block font-sans antialiased font-semibold leading-relaxed tracking-normal text-2xl text-blue-600">
                      {invoice.folio}
                    </h6>
                    <p className="text-slate-500 text-sm">{CurrencyFormatter({
                      currency: 'MXN',
                      value: invoice.total
                    })}</p>
                  </div>
                  <div className="flex justify-between items-center border border-slate-500">
                    <h6
                      className="block font-sans antialiased font-semibold leading-relaxed tracking-normal text-green-600">
                      {invoice.project.title}
                    </h6>
                    <p className="text-slate-500 text-sm">{invoice.concepts}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}

        </nav>
      </div>
    </>
  )

  return (
    <div className="mt-2">
      {view}
      <div className="flex justify-center mt-8 space-x-5">
        <Button type="button" 
          onClick={() => {
            NextStep(1); 
          }}>Atras</Button>
        <button type="button"
          onClick={() => saveCollection()}
          className="border w-36 h-9 bg-white font-normal text-sm text-slate-900 
            border-slate-900 rounded-xl hover:bg-slate-200"
        >
          Guardar
        </button>         
      </div>
    </div>
  );
}

function transformTypes(invoiceFrom: IInvoiceMin[]){
  const invoiceTo: TInvoiceStepper[]=[];
  Array.isArray(invoiceFrom) && invoiceFrom.map((i) => {
    invoiceTo.push({
      total: Array.isArray(i?.accountreceivables) && i?.accountreceivables?.length > 0? i.accountreceivables[0]?.charged : 0,
      totalPending: Array.isArray(i?.accountreceivables) && i?.accountreceivables?.length > 0? i.accountreceivables[0]?.unchargedbalanceamount : 0,
      id:i._id,
      project: {
        id: typeof(i.project)==='string'? i.project: i.project._id,
        title: typeof(i.project)==='string'? i.project: i.project.title
      },
      folio: i.folio,
      concepts: i.paymentWay+' | '+ i.paymentMethod + ' | ' + i.useCFDI,
      previousAmount: i?.accountreceivables?.length > 0? i.accountreceivables[0]?.previousbalanceamount : 0
    });
  });
  return invoiceTo;
}