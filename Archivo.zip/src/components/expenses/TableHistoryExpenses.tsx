'use client'
import { createColumnHelper } from "@tanstack/react-table";
import Table from "@/components/Table";
import Link from "next/link";
import { useState, useEffect, useMemo } from "react";
import { ExpensesTable, Expense } from "@/interfaces/Expenses";
import Chip from "../providers/Chip";
import { useNewExpense } from "@/app/store/newExpense";
import { ExpenseDataToTableData } from "@/app/functions/CostsFunctions";
import { GetCosts } from "@/app/api/routeCost";
import { showToastMessageError } from "../Alert";
import Filtering from "./ExpensesFiltered";
import { BsFileEarmarkPdf } from "react-icons/bs"; //Archivo PDF
import { BsFiletypeXml } from "react-icons/bs"; //Archivo XML
import { IoAlert } from "react-icons/io5"; // No hay archivo
import { CurrencyFormatter } from "@/app/functions/Globals";
import {Tooltip} from "@nextui-org/react";
import ContainerSideNav from "../ContainerSideNav";
import { propsTooltip } from "@/libs/animations";
import { IoIosLink } from "react-icons/io";
import { useTableStates } from "@/app/store/tableStates";

interface Props {
  data:ExpensesTable[], 
  token:string, 
  expenses:Expense[], 
  isFilter:boolean, 
  setIsFilter:(value: boolean) => void, 
  isViewReports: boolean,
  company: string,
}

export default function TableHistoryExpenses({data, token, expenses, 
  isFilter, setIsFilter, isViewReports, company}:Props){
  
  const columnHelper = createColumnHelper<ExpensesTable>();

  const [filter, setFilter] = useState<boolean>(false);
  const [dataExpenses, setDataExpenses] = useState(data);
  const [filteredExpenses, setFilteredExpenses] = useState<Expense[]>(expenses);

  const {refresh, updateRefresh} = useNewExpense();

  const columns = [
    columnHelper.accessor(row => row.id, {
      id: 'seleccion',
      cell: ({row}) => (
        <div className="flex gap-x-2">
          <input type="checkbox" 
            checked={row.getIsSelected()}
            onChange={row.getToggleSelectedHandler()}
          />
        </div>
      ),
      enableSorting:false,
      header: ({table}:any) => (
        <input type="checkbox"
          checked={table.getIsAllRowsSelected()}
          onClick={()=> {
            table.toggleAllRowsSelected(!table.getIsAllRowsSelected())
          }}
        />
      )
    }),
    columnHelper.accessor('Responsable', {
      id: 'Responsable',
      cell: ({row}) => (
        <div className="flex gap-x-1 items-center">
          <img src={row.original.Responsable.photo} className="w-6 h-auto rounded-full" alt="user" />
          {row.original.archivos.includes('xml') && (
            <Tooltip closeDelay={0} delay={100} motionProps={propsTooltip} content='XML' 
                placement="right" className="text-black bg-white rounded-md border border-slate-400">
              <span>
                <BsFiletypeXml className="w-6 h-6 text-green-500 hover:bg-blue-100" />
              </span>
            </Tooltip>
          )}
          {row.original.archivos.includes('pdf') && (
            <Tooltip closeDelay={0} delay={100} motionProps={propsTooltip} content='PDF' 
                placement="right" className="text-black bg-white rounded-md border border-slate-400">
              <span>
                <BsFileEarmarkPdf className="w-6 h-6 text-green-500 hover:bg-blue-100" />
              </span>
            </Tooltip>
          )}
          {row.original.archivos.includes('none') && (
            <Tooltip closeDelay={0} delay={100} motionProps={propsTooltip} content='Sin archivo' 
                placement="right" className="text-black bg-white rounded-md border border-slate-400">
              <span>
                <IoAlert className="w-6 h-6 text-red-500 hover:bg-blue-100" />
              </span>
            </Tooltip>
          )}
          {row.original.isCfdisRelations && (
            <Tooltip closeDelay={0} delay={100} motionProps={propsTooltip} content='CFDI relacionado' 
                placement="right" className="text-black bg-white rounded-md border border-slate-400">
              <span>
                <IoIosLink className="w-6 h-6 text-green-500 hover:bg-blue-100" />
              </span>
            </Tooltip>
          )}
        </div>
      ),
      enableSorting:false,
      header: () => (
        <p>Responsable</p>
      )
    }),
    columnHelper.accessor('Proyecto', {
      id: 'Proyecto',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="py-2 font-semibold">{row.original.Proyecto}</p>
        </Link>
      ),
      enableSorting:false,
      header: () => (
        <p>Proyecto</p>
      )
    }),
    columnHelper.accessor('Informe', {
      header: 'Informe',
      id: 'Informe',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="py-2 font-semibold">{row.original.Informe}</p>
        </Link>
      )
    }),
    columnHelper.accessor('costcenter', {
      header: 'Centro de costos',
      id: 'Centro de costos',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="py-2 font-semibold">{row.original.costcenter}</p>
        </Link>
      )
    }),
    columnHelper.accessor('Descripcion', {
      header: 'Descripcion',
      id: 'descripcion',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          {!row.original.Descripcion? "Sin descripcion": row.original.Descripcion.length < 100? (
            <p className="">{row.original.Descripcion}</p>
          ): (
            <p className="">{row.original.Descripcion.substring(0, 100)}</p>
          )}
        </Link>
      ),
    }),
    columnHelper.accessor('Proveedor', {
      header: 'Proveedor',
      id: 'proveedor',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">{row.original.Proveedor}</p>
        </Link>
      ),
    }),
    columnHelper.accessor('Estatus', {
      header: 'Estatus',
      id: 'estatus',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <Chip label={row.original.condition} color={row.original.color} darktext={row.original.darktext} />
        </Link>
      ),
    }),
    columnHelper.accessor('Fecha', {
      header: 'Fecha',
      id: 'fecha',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">{row.original.Fecha?.substring(0, 10) || ''}</p>
        </Link>
      ),
    }),
    columnHelper.accessor('Importe', {
      header: 'Importe',
      id: 'importe',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">
            {CurrencyFormatter({
              currency: 'MXN',
              value: row.original.Importe
            })}
          </p>
        </Link>
      ),
    }),
    columnHelper.accessor('vat', {
      header: 'IVA',
      id: 'iva',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">
            {CurrencyFormatter({
              currency: "MXN",
              value: row.original.vat
            })}
          </p>
        </Link>
      ),
    }),
    columnHelper.accessor('discount', {
      header: 'Descuento',
      id: 'descuento',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">
            {CurrencyFormatter({
              currency: 'MXN',
              value: row.original.discount
            })}
          </p>
        </Link>
      ),
    }),
    columnHelper.accessor('total', {
      header: 'Total',
      id: 'total',
      cell: ({row}) => (
        <Link href={`/expenses/history/${row.original.id}/profile`}>
          <p className="">
            {CurrencyFormatter({
              currency: 'MXN',
              value: row.original.total
            })}
          </p>
        </Link>
      ),
    }),
    columnHelper.accessor('taxFolio', {
      header: 'Folio fiscal',
      id: 'Folio fiscal',
      cell: ({row}) => (
        <p className="cursor-pointer"
          onClick={() => window.location.replace(`/expenses/history/${row.original.id}/profile`)}
        >{row.original.taxFolio}</p>
      ),
    }),
  ]
  
  const initialVisibilityColumns: any = {
    seleccion: true,
    Responsable: true, 
    Proyecto: true, 
    Informe: true, 
    "Centro de costos": true, 
    descripcion: true, 
    proveedor: true, 
    estatus: true, 
    fecha: true, 
    importe: true,
    iva: false,
    descuento: false,
    total: false,
    "Folio fiscal": false,
  }

  const [view, setView] = useState<JSX.Element>(<Table columns={columns} data={dataExpenses} 
                placeH="Buscar gasto.." typeTable='cost' initialColumns={initialVisibilityColumns} />);
  const [maxAmount, setMaxAmount] = useState<number>(0);
  const [minAmount, setMinAmount] = useState<number>(0);
  
  useEffect(() => {
    const expenseM = expenses.reduce((previous, current) => {
      return current.cost?.subtotal > previous.cost?.subtotal ? current : previous;
    });
    const expenseMin = expenses.reduce((previous, current) => {
      return current.cost?.subtotal < previous.cost?.subtotal ? current : previous;
    });
    setMaxAmount(expenseM.cost?.subtotal);
    setMinAmount(expenseMin.cost?.subtotal > 0? 0: expenseMin.cost?.subtotal || 0);
  }, [])

  useEffect(() => {
    if(refresh){
      const aux = async () =>{
        try {
          const res = await GetCosts(token);
          if(typeof(res) !== 'string'){
            const d = ExpenseDataToTableData(res);
            setDataExpenses(d);
            setView(<Table columns={columns} data={d} 
              placeH="Buscar gasto.." typeTable='cost' initialColumns={initialVisibilityColumns} />);
          }else{
            showToastMessageError(res);
          }
        } catch (error) {
          showToastMessageError('Error al actualizar tabla!!');
        }
      }
      aux();
      updateRefresh(false);
    }
  }, [refresh]);

  useEffect(() => {
    if(filter){
      setView(<></>);
      setTimeout(() => {
        setView(<Table columns={columns} data={dataExpenses} 
          placeH="Buscar gasto.." typeTable='cost' initialColumns={initialVisibilityColumns} />);
      }, 100);
      setFilter(false);
    }
  }, [filter]);

  const paidValidation = (exp:Expense, isPaid:number) => {
    if(isPaid===1){
      return true;
    }else{
      if(isPaid===2){
        if(exp.ispaid){
          return true;
        }
        return false;
      }else{
        if(!exp.ispaid){
          return true;
        }
        return false;
      }
    }
  }

  const dateValidation = (exp:Expense, startDate:number, endDate:number, isPaid:number) => {
    let d = new Date(exp.date).getTime();
    if(d >= startDate && d <= endDate){
      return paidValidation(exp, isPaid);
    }
    return false;
  }

  const amountValidation = (exp:Expense, minAmount:number, maxAmount:number, 
                              startDate:number, endDate:number, isPaid:number) => {
    if(exp.cost?.subtotal >= minAmount && exp.cost?.subtotal <= maxAmount){
      return dateValidation(exp, startDate, endDate, isPaid);
    }
    return false;
  }

  const providerValidation = (exp:Expense, minAmount:number, maxAmount:number, 
    startDate:number, endDate:number, providers:string[], isPaid:number) => {
    if(providers.includes('all')){
      return amountValidation(exp, minAmount, maxAmount, startDate, endDate, isPaid);
    }else{
      if(exp.provider){
        if(typeof(exp.provider)==='string'){
          if(providers.includes(exp.provider)){
            return amountValidation(exp, minAmount, maxAmount, startDate, endDate, isPaid);
          }
        }else{
          if(providers.some((prov) => prov === exp.provider._id)){
            return amountValidation(exp, minAmount, maxAmount, startDate, endDate, isPaid);
          }
        }
      }
    }
    return false;
  }

  const costCenterValidation = (exp:Expense, minAmount:number, maxAmount:number, isPaid:number, 
                      startDate:number, endDate:number, costcenters:string[], providers:string[]) => {
    if(costcenters.includes('all')){
      return providerValidation(exp, minAmount, maxAmount, startDate, endDate, providers, isPaid);
    }else{
      if(exp.costocenter){
        if(typeof(exp.costocenter)==='string'){
          if(costcenters.includes(exp.costocenter)){
            return providerValidation(exp, minAmount, maxAmount, startDate, endDate, providers, isPaid);
          }
        }else{
          if(costcenters.some((cc) => cc === (exp.costocenter._id + '/' + exp.costocenter.concept._id))){
            return providerValidation(exp, minAmount, maxAmount, startDate, endDate, providers, isPaid);
          }
        }
      }
    }
    return false;
  }

  const projectValidation = (exp:Expense, minAmount:number, maxAmount:number, 
                      startDate:number, endDate:number, projects:string[], 
                      costcenters:string[], providers:string[], isPaid:number) => {
    if(projects.includes('all')){
      return costCenterValidation(exp, minAmount, maxAmount, isPaid, startDate, endDate, costcenters, providers);
    }else{
      if(exp.project){
        if(projects.includes(exp.project._id)){
          return costCenterValidation(exp, minAmount, maxAmount, isPaid, startDate, endDate, costcenters, providers);
        }
      }
    }
    return false;
  }

  const reportValidation = (exp:Expense, minAmount:number, maxAmount:number, 
              startDate:number, endDate:number, projects:string[], isPaid:number, 
              reports:string[], costcenters: string[], providers:string[]) => {
    if(reports.includes('all')){
      return projectValidation(exp, minAmount, maxAmount, startDate, endDate, projects, costcenters, providers, isPaid); 
    }else{
      if(exp.report){
        if(reports.includes(exp.report._id)){
          return projectValidation(exp, minAmount, maxAmount, startDate, endDate, projects, costcenters, providers, isPaid);
        }
      }
    }
    return false;
  }

  const categoriesValidation = (exp:Expense, minAmount:number, maxAmount:number, 
                startDate:number, endDate:number, projects:string[], isPaid:number, 
                reports:string[], categories:string[], costcenters: string[], providers:string[]) => {
    
    if(categories.includes('all')){
      return reportValidation(exp, minAmount, maxAmount, startDate, endDate, projects, isPaid, reports, costcenters, providers);
    }else{
      if(exp.category){
        if(categories.includes(exp.category._id)){
          return reportValidation(exp, minAmount, maxAmount, startDate, endDate, projects, isPaid, reports, costcenters, providers);
        }
      }
    }
    return false;
  }

  const typesValidation = (exp:Expense, minAmount:number, maxAmount:number, 
                  startDate:number, endDate:number, projects:string[], 
                  reports:string[], categories:string[], types:string[], 
                  costcenters:string[], providers: string[], isPaid:number) => {
    
    if(types.includes('all')){
      return categoriesValidation(exp, minAmount, maxAmount, startDate, endDate, 
                projects, isPaid, reports, categories, costcenters, providers);
    }else{
      if(exp.typeCFDI){
        if(types.includes(exp.typeCFDI._id)){
          return categoriesValidation(exp, minAmount, maxAmount, startDate, endDate, 
                    projects, isPaid, reports, categories, costcenters, providers);
        }
      }
    }
    return false;
  }

  const conditionValidation = (exp:Expense, minAmount:number, maxAmount:number, 
                  startDate:number, endDate:number, projects:string[], 
                  reports:string[], categories:string[], types:string[], 
                  conditions:string[], costcenters: string[], providers: string[], isPaid:number) => {

    if(conditions.includes('all')){
      return typesValidation(exp, minAmount, maxAmount, startDate, endDate, projects, 
                reports, categories, types, costcenters, providers, isPaid);
    }else{
      if(conditions.includes(exp.estatus._id)){
        return typesValidation(exp, minAmount, maxAmount, startDate, endDate, projects, 
                    reports, categories, types, costcenters, providers, isPaid);
      }
    }
    return false;
  }

  const filterData = (conditions:string[], types:string[], 
    categories:string[], minAmount:number, maxAmount:number, 
    reports:string[], projects:string[], startDate:number, 
    endDate:number, costcenters:string[], providers:string[], isPaid:number) => {
  
    let filtered: Expense[] = [];
    expenses.map((expense) => {
      if(conditionValidation(expense, minAmount, maxAmount, startDate, 
          endDate, projects, reports, categories, types, conditions, costcenters, providers, isPaid)){
        filtered.push(expense);
      }
    });

    setFilteredExpenses(filtered);
    
    setDataExpenses(ExpenseDataToTableData(filtered));
    setFilter(true);
  }

  return(
    <>
      <div className="flex justify-end my-5">
        {isFilter && (
          <ContainerSideNav width="w-full max-w-[550px]">
            <Filtering showForm={setIsFilter} FilterData={filterData} maxAmount={maxAmount} company={company} token={token}
                        minAmount={minAmount} expensesFiltered={filteredExpenses} isViewReports={isViewReports} 
                      />
          </ContainerSideNav>
        )}
      </div>
      
      <div className="hidden md:block w-full">
        {view}
      </div>
      <div className="block md:hidden w-full">
        <ListData data={data} queryParam={''} />
      </div>
    </>
  )
}

const ListData = ({data, queryParam}: 
  {data: ExpensesTable[], queryParam:string}) => {

  // const [dataReports, setDataReports] = useState(data);
  const {search} = useTableStates();

  const filterData = useMemo(() => {
    if(search.trim() === ''){
      return data;
    }else{
      const d = data.filter(item => item.Descripcion.toLowerCase().includes(search.toLowerCase()));
      return d;
    }
  }, [search]);

  return(
    <div>
      <div className="relative flex flex-col text-gray-700 bg-white shadow-md w-full rounded-xl bg-clip-border] h-[calc(100vh-264px)]">
        <nav className="flex w-full flex-col gap-1 p-2 font-sans text-base font-normal text-blue-gray-700
          overflow-scroll overflow-y-auto overflow-x-hidden" style={{scrollbarColor: '#ada8a8 white', scrollbarWidth: 'thin'}}>

          {filterData.map((e) => (
            <CardExpense expense={e} key={e.id} queryParam={queryParam} />
          ))}

        </nav>
      </div>
    </div>
  )
}

const CardExpense = ({expense, queryParam}: 
  {expense:ExpensesTable, queryParam:string}) => {
  
  return(
    <div role="button"
      key={expense.id}
      className={`flex flex-col w-full p-3 leading-tight transition-all rounded-lg 
        outline-none text-start hover:bg-blue-gray-50 hover:bg-opacity-80 hover:text-blue-gray-900 
        focus:bg-blue-gray-50 focus:bg-opacity-80 focus:text-blue-gray-900 active:bg-blue-gray-50 
        active:bg-opacity-80 active:text-blue-gray-900 border-b border-slate-300 
        bg-white`}
      onClick={() => window.location.replace(`/expenses/${expense.id}/profile${queryParam}`)}
    >
      <div className="flex items-center w-full ">
        <div className="grid mr-4 place-items-center">
          <img alt="responsable" src={ expense.Responsable?.photo ?? '/img/users/default.jpg'}
            className="relative inline-block h-12 w-12 !rounded-full  object-cover object-center" />
        </div>
        <div className="w-full">
          <div className="flex gap-x-3 w-full justify-between items-center p-3">
            <div>
              <h6
                className="block font-sans text-sm antialiased font-semibold leading-relaxed tracking-normal text-gray-600 ">
                {expense.Proyecto}
              </h6>
              {/* <p className="block font-sans text-sm antialiased font-normal leading-normal text-gray-600">
                {expense.Descripcion}
              </p> */}
            </div>
            <div className="text-right">
              <p className="block font-sans text-2xl antialiased font-normal leading-normal text-blue-600">
                {CurrencyFormatter({
                  currency: 'MXN',
                  value: expense.Importe
                })}
              </p>
              <p className="block font-sans text-xs antialiased font-normal leading-normal text-gray-600">
                {expense.Informe}
              </p>
            </div>
          </div>
        </div>
      </div>

      <p className="block font-sans text-sm antialiased font-normal leading-normal text-gray-600">
        {expense.Descripcion}
      </p>

    </div>
  )
}