"use client"
import Label from "../Label"
import Input from "../Input"
import { useFormik } from "formik"
import * as Yup from 'yup';
import Button from "../Button";
import { Options } from "@/interfaces/Common";
import SelectReact from "../SelectReact";
import { useState, useRef, useEffect } from "react";
import "react-datepicker/dist/react-datepicker.css";
import NavExpenseStepper from "./NavExpenseStepper"
import { useNewExpense } from "@/app/store/newExpense"
import SaveExpense from "@/app/functions/SaveExpense"
import { showToastMessage, showToastMessageError } from "../Alert"
import { PlusCircleIcon } from "@heroicons/react/24/solid"
import AddProvider from "./AddProvider"
import { CreateCostWithFiles } from "@/app/api/routeCost"
import CurrencyInput from 'react-currency-input-field';
import { getSupplierCreditProv } from "@/app/functions/CostsFunctions"

import { useOptionsExpense } from "@/app/store/newExpense";
import { getProvider } from "@/app/api/routeProviders";
import { Provider } from "@/interfaces/Providers";
import { getAllCostsByProviderNEConditionLV } from "@/app/api/routeCost";
import Select from 'react-select'

export default function DataStepper({token, user, handleUpdateCategory, company}: 
  {token:string, user:string, handleUpdateCategory: (value: string) => void, company:string }){
  
  const {updateIndexStepper, updateBasicData, CFDI, voucher, amount, 
    costCenter, date, description, discount, 
    folio, project, proveedor, responsible, taxFolio, 
    typeCFDI, vat, reset, updateRefresh, isCard, 
    report, condition, category, isPettyCash, concept,
    updateIsCard, updateCostCenter, updateHaveDiscount, 
    updateHaveTaxExempt, haveDiscount, haveTaxExempt, taxExempt, 
    total, reportObject, dataCFDI, updateCategory} = useNewExpense();

  const {costCenterOpt, providers, providersSAT, responsibles, categories, types, 
    vats, addProvider, addProviderSat} = useOptionsExpense();

  const [optionsInvoices, setOptionsInvoices] = useState<Options[]>([]);
  const [optInvoice, setOptInvoice]=useState<Options>();

  let year = new Date().getFullYear().toString();
  let month = (new Date().getMonth() + 1).toString();
  let day = new Date().getDate().toString();
  if(month.length ===1) month = '0'+month;
  if(day.length ===1) day = '0'+day;

  const d = year+'-'+month+'-'+day;

  const dateDat = dataCFDI? dataCFDI.date: date;

  const [startDate, setStartDate] = useState<string>(dateDat!== ''? dateDat: d);
  const [typeCFDIS, setTypeCFDIS] = useState<string>(types[0].value);
  const [provider, setProvider] = useState<string>(dataCFDI? dataCFDI.proveedor: providers[0].value);
  const [responsibleS, setResponsibleS] = useState<string>(responsible!==''? responsible: user);
  
  const [showProvider, setShowProvider] = useState<boolean>(false);
  const refRequest = useRef(true);
  
  const [idVat, setIdVat] = useState<string>(vats[0].value);
  const [vatValue, setVatValue] = useState<string>(dataCFDI? dataCFDI.vat: '0');
  const [isNoBusinessName, setIsNoBusinesName] = useState<boolean>(false);
  const [totalExpense, setTotalExpense] = useState<string>(dataCFDI? dataCFDI.total : total);

  // const [typeCFDISprov, setTypeCFDISprov] = useState<string>(types[0].value);
  const [CFDISrelation, setCFDISrelations] = useState<string>();

  const handleOptInvoice = (value: Options) => {
    setOptInvoice(value);
  }

  const fetchInvoices = async(provParam:string) => {
    const res = await getAllCostsByProviderNEConditionLV(token, provParam);
    if(typeof(res)!=='string'){
      setOptionsInvoices(res);
      setOptInvoice(res.length>0? res[0]: undefined);
      setCFDISrelations(res.length>0? res[0].value : undefined);
    }else{
      showToastMessageError(res);
    }
  }

  useEffect(() => {
    fetchInvoices(dataCFDI? dataCFDI.proveedor: providers[0].value);
  }, []);

  const formik = useFormik({
    initialValues: {
      folio: dataCFDI? dataCFDI.folio: folio,
      taxFolio: dataCFDI? dataCFDI.taxFolio : taxFolio,
      description: dataCFDI? dataCFDI.concepts : description,
      discount: dataCFDI? dataCFDI?.discount : discount,
      amount: dataCFDI? dataCFDI.amount : amount,
      vat: vat,
      taxExempt: taxExempt,
    }, 
    validationSchema: Yup.object({
      description: Yup.string()
                  .required('La descripcion es obligatoria!!'),
      folio: Yup.string()
                  .required('El folio es obligatorio'),
      taxFolio: Yup.string()
                  .required('El folio fiscal es obligatorio'),
      discount: Yup.string(),
      amount: Yup.string()
                  .required('El importe es obligatorio!!!'),
      vat: Yup.string(),
      taxExempt: Yup.string(),
    }),
    onSubmit: async (valores) => {            
      const {description, folio, taxFolio, discount, amount, vat, taxExempt} = valores;
      updateBasicData(folio, description, amount.replace(/[$,]/g, ""), 
          startDate, taxFolio, vat.replace(/[$,]/g, ""), discount.replace(/[$,]/g, ""), provider, responsibleS, 
          typeCFDIS, '', idVat, 'PROVEEDOR', taxExempt.replace(/[$,]/g, ""), totalExpense.replace(/[$,]/g, ""));
          //categoryS,
      updateIndexStepper(2);
    },
  });
  
  const updateIva = (idValue: string) => {
    try {
      const foundVat = vats.find((vat) => vat.value === idValue);
      const vatval = foundVat?.label || '0';
      let operation;
      let t = 0;
      if(haveDiscount && haveTaxExempt){
        operation = (Number(formik.values.amount.replace(/[$,]/g, "")) - 
                        Number(formik.values.discount.replace(/[$,]/g, "")) -
                        Number(formik.values.taxExempt.replace(/[$,]/g, ""))) * 
                          Number(vatval) / 100;
        
        t = Number(formik.values.amount.replace(/[$,]/g, "")) -
              Number(formik.values.discount.replace(/[$,]/g, "")) +
              operation;
      }else{
        if(haveDiscount){
          operation = (Number(formik.values.amount.replace(/[$,]/g, "")) - 
                        Number(formik.values.discount.replace(/[$,]/g, ""))) * 
                          Number(vatval) / 100;

          t = Number(formik.values.amount.replace(/[$,]/g, "")) -
                Number(formik.values.discount.replace(/[$,]/g, "")) +
                operation;
        }else{
          if(haveTaxExempt){
            operation = (Number(formik.values.amount.replace(/[$,]/g, "")) - 
                        Number(formik.values.taxExempt.replace(/[$,]/g, ""))) * 
                          Number(vatval) / 100;

            t = Number(formik.values.amount.replace(/[$,]/g, "")) + operation;              
          }else{
            operation = (Number(formik.values.amount.replace(/[$,]/g, ""))) * 
                          Number(vatval) / 100;
                
            t = Number(formik.values.amount.replace(/[$,]/g, "")) + operation;
          }
        }
      }
      
      formik.values.vat = operation.toFixed(2).toString();
      setVatValue(operation.toFixed(2).toString());
      setTotalExpense(t.toFixed(2).toString())
    } catch (error) {
      setVatValue('0');
      formik.values.vat = '0';
    }
  }

  const updateTotal = (valueIva: string) => {
    try {
      let t = 0;
      if(haveDiscount){
        t = Number(formik.values.amount.replace(/[$,]/g, "")) -
              Number(formik.values.discount.replace(/[$,]/g, "")) +
              Number(valueIva.replace(/[$,]/g, ""));
      }else{
        t = Number(formik.values.amount.replace(/[$,]/g, "")) +
              Number(valueIva.replace(/[$,]/g, ""));
      }
      setTotalExpense(t.toFixed(2).toString());
    } catch (error) {
      setTotalExpense('0');
    }
  }

  let viewAmount: JSX.Element = <></>;
  viewAmount = (
    <CurrencyInput
      id="amount"
      name="amount"
      className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white
        focus:border-slate-700 outline-0"
      onChange={formik.handleChange}
      onBlur={formik.handleChange}
      value={formik.values.amount.replace(/[$,]/g, "")}
      decimalsLimit={2}
      prefix="$"
      onValueChange={(value) => {try {
        formik.values.amount=value || '0';
        handleIdVat(idVat);
      } catch (error) {
        formik.values.amount='0';
        handleIdVat(idVat);
      }}}
    />
  )

  let viewTotal: JSX.Element = <></>;
  viewTotal = (
    <CurrencyInput
      id="total"
      name="total"
      className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white
        focus:border-slate-700 outline-0"
      value={totalExpense.replace(/[$,]/g, "")}
      decimalsLimit={2}
      prefix="$"
      onValueChange={(value) => {try {
        setTotalExpense(value || '0');
      } catch (error) {
        setTotalExpense('0');
      }}}
    />
  )

  useEffect(() => {
    if(costCenter===''){
      handleConstCenter(costCenterOpt[0].value);
    }
  }, []);

  const SaveData = async() => {
    refRequest.current = false;
    const {description, folio, taxFolio, discount, amount, vat, taxExempt} = formik.values
    updateBasicData(folio, description, amount.replace(/[$,]/g, ""), 
        startDate, taxFolio, vat, discount.replace(/[$,]/g, ""), provider, responsibleS, 
        typeCFDIS, '', idVat.replace(/[$,]/g, ""), 'PROVEEDOR', 
        taxExempt.replace(/[$,]/g, ""), totalExpense.replace(/[$,]/g, ""));
        //categoryS,
    
    let supplierCredit: boolean;
    try {
      supplierCredit = await getSupplierCreditProv(token, provider);
    } catch (error) {
      supplierCredit = false;
    }
    
    const costcenter = {
      category: costCenter,
      concept
    }

    if(!formik.values.description || formik.values.description===''){
      refRequest.current = true;
      showToastMessageError("No se ha agregado una descripcion al gasto!!");
    }else{
      if(voucher || CFDI){
        let val=true;
        if(CFDI){
          val = await dataCFDIValidation();
          if(!val){
            refRequest.current = true;
            showToastMessageError('El CFDI adjuntado no es valido con la informacion ingresada!!');
          }
        }

        if(val){
          const formdata = new FormData();
          formdata.append('costocenter', JSON.stringify(costcenter));
          formdata.append('date', startDate);
          formdata.append('description', description);
          formdata.append('folio', folio);
          formdata.append('provider', provider);
          formdata.append('user', responsibleS);
          formdata.append('taxfolio', taxFolio);
          formdata.append('typeCFDI', typeCFDIS);
          formdata.append('category', category);
          formdata.append('project', project);
          formdata.append('report', report);
          formdata.append('isticket', JSON.stringify(false));
          formdata.append('iscard', JSON.stringify(isCard));
          formdata.append('type', 'PROVEEDOR');
          formdata.append('company', company);
          formdata.append('exempttax', taxExempt.replace(/[$,]/g, ""));
          formdata.append('conditionprovider', JSON.stringify([{
            glossary: '674643dd734d5ab78ab98ddb',
            user
          }]));
          formdata.append('condition', JSON.stringify([{
            glossary: condition,
            user
          }]));
          formdata.append('cost', JSON.stringify({
            discount: discount.replace(/[$,]/g, ""),
            subtotal:amount.replace(/[$,]/g, ""),
            // iva:vat.replace(/[$,]/g, ""),
            iva: vatValue.replace(/[$,]/g, ""),
            vat: idVat, 
            exempttax: taxExempt.replace(/[$,]/g, ""),
            total: totalExpense.replace(/[$,]/g, "")
          }));
          if(voucher){
            formdata.append('files', voucher);
            formdata.append('types', voucher.type);

          }
          if(CFDI){
            formdata.append('files', CFDI);
            formdata.append('types', CFDI.type);
          }

          if(concept==="6691a5f9c14942310b52ac0e"){
            formdata.append('cfdisRelations', JSON.stringify({cfdisRelations: {                
              relatedUUIDs: [CFDISrelation],                        
              typeUUID: "07 CFDI por aplicacion de anticipo",                                     
            }}));
            formdata.append('isCfdisRelations', JSON.stringify(true));
          }

          if(concept==="6691a5f9c14942310b52ac0c"){
            formdata.append('isadvancesToSuppliers', JSON.stringify(true));
            formdata.append('advancesToSuppliers', JSON.stringify({
                currentbalance: Number(totalExpense.replace(/[$,]/g, "")),
                percentadvance: 100,
                user,
                notes:[],
                advanceInvoicesCfdis:[]
              }));
          }

          try {
            formdata.append('ispaid', JSON.stringify(supplierCredit));
            if(reportObject && reportObject.ispettycash){
              const fechaGasto = new Date(startDate);
              const fechaReport = new Date(reportObject.date);
              const currentDate = new Date();
              const expiration = new Date(reportObject.expirationdate);
              if( (fechaGasto > fechaReport || fechaGasto.getTime() >= fechaReport.getTime())  && 
                  (currentDate < expiration || currentDate.getTime() <= currentDate.getTime())){
                const res = await CreateCostWithFiles(token, formdata);
                if(res === 201){
                  const catAux=category;
                  reset();
                  formik.values.amount = '';
                  formik.values.description = '';
                  formik.values.discount = '';
                  formik.values.folio = '';
                  formik.values.taxFolio = '';
                  formik.values.vat = '';
                  setTotalExpense('0');
                  showToastMessage('Costo creado satisfactoriamente!!!');
                  updateRefresh(true);
                  updateIndexStepper(4);
                  refRequest.current = true;
                  updateCategory(catAux);
                }else{
                  refRequest.current = true;
                  showToastMessageError(res);
                }
              }else{
                refRequest.current = true;
                showToastMessageError('Error al ingresar, la fecha del gasto no cumple con las politicas de la empresa!!!');
              }
            }else{
              const res = await CreateCostWithFiles(token, formdata);
              if(res === 201){
                const catAux=category;
                reset();
                formik.values.amount = '';
                formik.values.description = '';
                formik.values.discount = '';
                formik.values.folio = '';
                formik.values.taxFolio = '';
                formik.values.vat = '';
                setTotalExpense('0');
                showToastMessage('Costo creado satisfactoriamente!!!');
                updateRefresh(true);
                updateIndexStepper(4);
                refRequest.current = true;
                updateCategory(catAux);
              }else{
                refRequest.current = true;
                showToastMessageError(res);
              }
            }
          } catch (error) {
            refRequest.current = true;
            showToastMessageError('Ocurrio un error al guardar costo!!');
          }
        }
        
      }else{
        const data = {
          costocenter:costcenter, date:startDate, description, 
          cost: {
            discount: discount.replace(/[$,]/g, ""),
            subtotal:amount.replace(/[$,]/g, ""),
            // iva:vat.replace(/[$,]/g, ""),
            iva: vatValue.replace(/[$,]/g, ""),
            vat: idVat,
            exempttax: taxExempt.replace(/[$,]/g, ""),
            total: totalExpense.replace(/[$,]/g, "")
          },
          folio, provider, user:responsibleS, 
          company,
          taxfolio:taxFolio, typeCFDI: typeCFDIS, project, ispaid:supplierCredit,
          report, isticket:false, category:category,
          conditionprovider: [{
            glossary: '674643dd734d5ab78ab98ddb',
            user
          }], 
          condition: [{
            glossary: condition,
            user
          }], iscard:isCard, type:'PROVEEDOR',
          ...(concept==="6691a5f9c14942310b52ac0e" && {
                cfdisRelations: {                
                relatedUUIDs: [CFDISrelation],                        
                typeUUID: "07 CFDI por aplicacion de anticipo",                                     
              },
              isCfdisRelations:true
            }),
          ...(concept==="6691a5f9c14942310b52ac0c" && {
              isadvancesToSuppliers:true,
              advancesToSuppliers: {
                currentbalance: Number(totalExpense.replace(/[$,]/g, "")),
                percentadvance: 100,
                user,
                notes:[],
                advanceInvoicesCfdis:[]
              }
            }),
        }

        try {
          if(reportObject && reportObject.ispettycash){
            const fechaGasto = new Date(startDate);
            const fechaReport = new Date(reportObject.date);
            const currentDate = new Date();
            const expiration = new Date(reportObject.expirationdate);
            if( (fechaGasto > fechaReport || fechaGasto.getTime() >= fechaReport.getTime())  && 
                (currentDate < expiration || currentDate.getTime() <= currentDate.getTime())){
              const res = await SaveExpense(data, token);
              if(res===201){
                const catAux=category;
                reset();
                formik.values.amount = '';
                formik.values.description = '';
                formik.values.discount = '';
                formik.values.folio = '';
                formik.values.taxFolio = '';
                formik.values.vat = '';
                setTotalExpense('0');
                showToastMessage('Costo creado satisfactoriamente!!!');
                updateRefresh(true);
                updateIndexStepper(4);
                refRequest.current = true;
                updateCategory(catAux);
              }
              else{
                showToastMessageError(res);
                refRequest.current = true;
              }
            }else{
              showToastMessageError('Error al ingresar, la fecha del gasto no cumple con las politicas de la empresa!!!');
              refRequest.current = true;
            }
          }else{
            console.log('data => ', JSON.stringify(data));
            const res = await SaveExpense(data, token);
            if(res===201){
              const catAux=category;
              reset();
              formik.values.amount = '';
              formik.values.description = '';
              formik.values.discount = '';
              formik.values.folio = '';
              formik.values.taxFolio = '';
              formik.values.vat = '';
              setTotalExpense('0');
              showToastMessage('Costo creado satisfactoriamente!!!');
              updateRefresh(true);
              updateIndexStepper(4);
              refRequest.current = true;
              updateCategory(catAux);
            }
            else{
              showToastMessageError(res);
              refRequest.current = true;
            }
          }
        } catch (error) {
          refRequest.current = true;
          showToastMessageError('Ocurrio un error al guardar costo!!');
        }
      }
    }
  }

  const dataCFDIValidation = async() => {
    const found = types.find((type) => type.value === typeCFDIS);
    let absolute=false;
    if(found){
      if(found.label.toLowerCase().includes('egreso')){
        absolute=true;
      }
    }

    if(absolute){
      if(Math.abs(Number(formik.values.amount.replace(/[$,]/g, ""))) !== Number(dataCFDI?.amount)){
        showToastMessageError('El importe ingresado no coincide con el del CFDI!!');
        return false;
      }
    }else{
      if(Number(formik.values.amount.replace(/[$,]/g, "")) !== Number(dataCFDI?.amount)){
        showToastMessageError('El importe ingresado no coincide con el del CFDI!!');
        return false;
      }
    }
    
    if(startDate.substring(0, 10) !== dataCFDI?.date.substring(0, 10)){
      showToastMessageError('La fecha ingresada no coincide con la del CFDI!!');
      return false;
    }
    if(formik.values.taxFolio !== dataCFDI.taxFolio){
      showToastMessageError('El folio fiscal ingresado no coincide con el del CFDI!!');
      return false;
    }
    try {
      const res:Provider = await getProvider(provider, token);
      if(typeof(res)==='string'){
        showToastMessageError('Error al validar proveedor!!');
        return false
      }
      if(res.rfc !== dataCFDI.RFCProvider){
        showToastMessageError('El rfc del proveedor no coincide con el del CFDI!!');
        return false;
      }
    } catch (error) {
      showToastMessageError('Error al validar proveedor!!');
      return false
    }
    return true;
  }

  const addProv = (newProviderSAT:Options, newProvider:Options) => {
    addProvider(newProvider);
    addProviderSat(newProviderSAT);
  }

  let indexProvider = 0;
  if(provider !== '' || dataCFDI?.proveedor){
    const valProv = dataCFDI? dataCFDI.proveedor: proveedor;
    providers.map((opt, index:number) => {
      if(opt.value === valProv){
        indexProvider = index;
      }
    });
  }

  let indexProviderSAT = 0;
  if(provider !== '' || dataCFDI?.proveedor){
    const valProv = dataCFDI? dataCFDI.proveedor: proveedor;
    providersSAT.map((opt, index:number) => {
      if(opt.value === valProv){
        indexProviderSAT = index;
      }
    });
  }

  const handleProvider = (value : string) => {
    setProvider(value);

    if (concept === '6691a5f9c14942310b52ac0e') {
      fetchInvoices(value);
    }
  }

  const viewProvider = (
    <div className="flex gap-x-2 items-center">
      <SelectReact index={indexProvider} opts={providers} setValue={handleProvider} />
      <PlusCircleIcon className="w-8 h-8 text-green-500 cursor-pointer hover:text-green-400" 
      onClick={() => setShowProvider(true)} />
    </div>
  )

  const viewProviderSAT = (
    <div className="flex gap-x-2 items-center">
      <SelectReact index={indexProviderSAT} opts={providersSAT} setValue={handleProvider} />
      <PlusCircleIcon className="w-8 h-8 text-green-500 cursor-pointer hover:text-green-400" 
      onClick={() => setShowProvider(true)} />
    </div>
  )

  let indexTypeCFDI = 0;
  if(typeCFDIS !== ''){
    types.map((opt, index:number) => {
      if(opt.value === typeCFDI){
        indexTypeCFDI = index;
      }
    });      
  }

  const handleTypeCfdi = (value: string) => {
    handleTypeCategoryCFDI(value);
    setTypeCFDIS(value);
  }

  const handleCfdirelations = (value: string) => {
    setCFDISrelations(value);
  }

  const view = (
    <>
      <div>
        <Label htmlFor="typeCFDI"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Tipo de CFDI</p></Label>
        <SelectReact index={indexTypeCFDI} opts={types} setValue={handleTypeCfdi} />
      </div>
    </>
  );

  let indexCC = 0;
  if(costCenter !== ''){
    costCenterOpt.map((opt, index:number) => {
      if(opt.value === costCenter + '/' + concept){
        indexCC = index;
      }
    });
  }

  const handleConstCenter = (value : string) => {
    const indexCaracter = value.indexOf('/');
    const c1 = value.substring(0, indexCaracter);
    const c2 = value.substring(indexCaracter + 1);
    updateCostCenter(c1, c2);

    if(c2 === '6691a5f9c14942310b52ac0e') {
      fetchInvoices(provider);
    }
  }

  const viewCC = (
    <div className=" col-span-1 md:col-span-3">
      <Label htmlFor="costcenter"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Centro de costos</p></Label>
      <SelectReact index={indexCC} opts={costCenterOpt} setValue={handleConstCenter} />
    </div>
  );

  let indexResp = 0;
  if(responsibleS !== ''){
    responsibles.map((opt, index:number) => {
      if(opt.value === responsibleS){
        indexResp = index;
      }
    });      
  }

  let viewResponsible = (
    <div>
      <Label htmlFor="responsible"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Responsable</p></Label>
      <SelectReact index={indexResp} opts={responsibles} setValue={setResponsibleS} />
    </div>
  );

  const handleTypeCategoryCFDI = (catType: string) => {
    if(catType !== ''){
      const found = types.find((type) => type.value === catType);
      if(found){
        if(found.label.toLowerCase().includes('egreso')){
          let num = Number(formik.values.amount.replace(/[$,]/g, ""));
          if(num > 0){
            num = num * -1;
            formik.values.amount = num.toString();
          }
          let numTotal = Number(totalExpense.replace(/[$,]/g, ""));
          if(numTotal > 0){
            setTotalExpense((numTotal * -1).toString());
          }
          let ivaTotal = Number(vatValue.replace(/[$,]/g, ""));
          if(ivaTotal > 0){
            formik.values.vat= (ivaTotal * -1).toString();
            setVatValue((ivaTotal * -1).toString());
          }
        }else{
          let num = Number(formik.values.amount.replace(/[$,]/g, ""));
          if(num < 0){
            num = Math.abs(num) ;
            formik.values.amount = num.toString();
          }
          let numTotal = Number(totalExpense.replace(/[$,]/g, ""));
          if(numTotal < 0){
            setTotalExpense((numTotal * -1).toString());
          }
          let ivaTotal = Number(vatValue.replace(/[$,]/g, ""));
          if(ivaTotal < 0){
            formik.values.vat= (ivaTotal * -1).toString();
            setVatValue((ivaTotal * -1).toString());
          }    
        }
      }
    }
  }

  const handleIdVat = (value: string) => {
    updateIva(value);
    setIdVat(value);
  };

  // if concept == 6691a5f9c14942310b52ac0e

  return(
    <div className="w-full bg-white">
      <div className="mt-2">
        <NavExpenseStepper index={3} />
      </div>
      <form onSubmit={formik.handleSubmit} className="mt-4 max-w-3xl rounded-lg">
        <div className="flex gap-x-5 justify-end my-5 pr-3">
          <div className="inline-flex items-center">
            <Label>Descuento</Label>  
            <div className="relative inline-block w-8 h-4 rounded-full cursor-pointer">
              <input checked={haveDiscount} 
                onClick={() => updateHaveDiscount(!haveDiscount)} id="discount" type="checkbox"
                onChange={() => console.log('')}
                className="absolute w-8 h-4 transition-colors duration-300 rounded-full 
                  appearance-none cursor-pointer peer bg-blue-gray-100 checked:bg-green-500 
                  peer-checked:border-green-500 peer-checked:before:bg-green-500
                  border border-slate-300" />
              <label htmlFor="discount"
                className="before:content[''] absolute top-2/4 -left-1 h-5 w-5 -translate-y-2/4 cursor-pointer rounded-full border border-blue-gray-100 bg-white shadow-md transition-all duration-300 before:absolute before:top-2/4 before:left-2/4 before:block before:h-10 before:w-10 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-blue-gray-500 before:opacity-0 before:transition-opacity hover:before:opacity-10 peer-checked:translate-x-full peer-checked:border-green-500 peer-checked:before:bg-green-500">
                <div className="inline-block p-5 rounded-full top-2/4 left-2/4 -translate-x-2/4 -translate-y-2/4"
                  data-ripple-dark="true"></div>
              </label>
            </div>
          </div>

          <div className="inline-flex items-center">
            <Label>Iva exento</Label>  
            <div className="relative inline-block w-8 h-4 rounded-full cursor-pointer">
              <input checked={haveTaxExempt} 
                onClick={() => updateHaveTaxExempt(!haveTaxExempt)} id="exemptTax" type="checkbox"
                onChange={() => console.log('')}
                className="absolute w-8 h-4 transition-colors duration-300 rounded-full 
                  appearance-none cursor-pointer peer bg-blue-gray-100 checked:bg-green-500 
                  peer-checked:border-green-500 peer-checked:before:bg-green-500
                  border border-slate-300" />
              <label htmlFor="exemptTax"
                className="before:content[''] absolute top-2/4 -left-1 h-5 w-5 -translate-y-2/4 cursor-pointer rounded-full border border-blue-gray-100 bg-white shadow-md transition-all duration-300 before:absolute before:top-2/4 before:left-2/4 before:block before:h-10 before:w-10 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-blue-gray-500 before:opacity-0 before:transition-opacity hover:before:opacity-10 peer-checked:translate-x-full peer-checked:border-green-500 peer-checked:before:bg-green-500">
                <div className="inline-block p-5 rounded-full top-2/4 left-2/4 -translate-x-2/4 -translate-y-2/4"
                  data-ripple-dark="true"></div>
              </label>
            </div>
          </div>

          {isPettyCash && (
            <div className="inline-flex items-center">
              <Label>Tarjeta</Label>  
              <div className="relative inline-block w-8 h-4 rounded-full cursor-pointer">
                <input checked={isCard} 
                  onClick={() => updateIsCard(!isCard)} id="switch-3" type="checkbox"
                  onChange={() => console.log('')}
                  className="absolute w-8 h-4 transition-colors duration-300 rounded-full 
                    appearance-none cursor-pointer peer bg-blue-gray-100 checked:bg-green-500 
                    peer-checked:border-green-500 peer-checked:before:bg-green-500
                    border border-slate-300" />
                <label htmlFor="switch-3"
                  className="before:content[''] absolute top-2/4 -left-1 h-5 w-5 -translate-y-2/4 cursor-pointer rounded-full border border-blue-gray-100 bg-white shadow-md transition-all duration-300 before:absolute before:top-2/4 before:left-2/4 before:block before:h-10 before:w-10 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-blue-gray-500 before:opacity-0 before:transition-opacity hover:before:opacity-10 peer-checked:translate-x-full peer-checked:border-green-500 peer-checked:before:bg-green-500">
                  <div className="inline-block p-5 rounded-full top-2/4 left-2/4 -translate-x-2/4 -translate-y-2/4"
                    data-ripple-dark="true"></div>
                </label>
              </div>
            </div>
          )}

        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-3 gap-y-5">
          {viewCC}
          <div>
            <Label htmlFor="folio"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Folio</p></Label>
            <Input type="text" name="folio" autoFocus 
              value={formik.values.folio}
              onChange={formik.handleChange}
              onBlur={formik.handleChange}
            />
            {formik.touched.folio && formik.errors.folio ? (
              <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                <p>{formik.errors.folio}</p>
              </div>
            ) : null}
          </div>
          <div className=" col-span-1 sm:col-span-2">
            <Label htmlFor="taxFolio"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Folio Fiscal</p></Label>
            <Input type="text" name="taxFolio" 
              value={formik.values.taxFolio}
              onChange={formik.handleChange}
              onBlur={formik.handleChange}
            />
            {formik.touched.taxFolio && formik.errors.taxFolio ? (
                <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                    <p>{formik.errors.taxFolio}</p>
                </div>
            ) : null}
          </div>
          <div>
            <Label htmlFor="amount"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Importe</p></Label>
            {viewAmount}
            {formik.touched.amount && formik.errors.amount ? (
              <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                <p>{formik.errors.amount}</p>
              </div>
            ) : null}
          </div>
          {haveDiscount && (
            <div>
              <Label htmlFor="discount">Descuento</Label>
              <CurrencyInput
                id="discount"
                name="discount"
                className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white 
                  focus:border-slate-700 outline-0"
                onChange={formik.handleChange}
                onBlur={formik.handleChange}
                value={formik.values.discount.replace(/[$,]/g, "") || 0}
                decimalsLimit={2}
                prefix="$"
                onValueChange={(value) => {try {
                  formik.values.discount=value || '0';
                  handleIdVat(idVat);
                } catch (error) {
                  handleIdVat(idVat);
                  formik.values.discount='0';
                }}}
              />
              {formik.touched.discount && formik.errors.discount ? (
                <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                  <p>{formik.errors.discount}</p>
                </div>
              ) : null}
            </div>
          )}
          {haveTaxExempt && (
            <div>
              <Label htmlFor="taxExemptt">Iva exento</Label>
              <CurrencyInput
                id="taxExemptt"
                name="taxExemptt"
                className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white 
                  focus:border-slate-700 outline-0"
                onChange={formik.handleChange}
                onBlur={formik.handleChange}
                value={formik.values.taxExempt.replace(/[$,]/g, "") || 0}
                decimalsLimit={2}
                prefix="$"
                onValueChange={(value) => {try {
                  formik.values.taxExempt=value || '0';
                  handleIdVat(idVat);
                } catch (error) {
                  formik.values.taxExempt='0';
                  handleIdVat(idVat);
                }}}
              />
              {formik.touched.taxExempt && formik.errors.taxExempt ? (
                <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                  <p>{formik.errors.taxExempt}</p>
                </div>
              ) : null}
            </div>
          )}
          <div>
            <div className="flex justify-between">
              <Label htmlFor="vat"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Iva</p></Label>
              <Label htmlFor="vatt"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Impuestos</p></Label>
            </div>
            <div className="flex gap-x-3">
              <CurrencyInput
                id="vat"
                name="vat"
                className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white 
                  focus:border-slate-700 outline-0"
                onChange={formik.handleChange}
                onBlur={formik.handleChange}
                decimalsLimit={2}
                value={vatValue}
                prefix="$"
                onValueChange={(value) => {try {
                  formik.values.vat=value || '0';
                  updateTotal(value || '0');
                  setVatValue(value || '0');
                } catch (error) {
                  formik.values.vat='0';
                  setVatValue('0');
                }}}
              />
              {formik.touched.vat && formik.errors.vat ? (
                  <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
                      <p>{formik.errors.vat}</p>
                  </div>
              ) : null}
              <SelectReact index={0} opts={vats} setValue={handleIdVat} />
            </div>
          </div>
          <div>
            <Label htmlFor="total"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Total</p></Label>
            {viewTotal}
          </div>
          <div>
            <Label htmlFor="date"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Fecha</p></Label>
            <Input 
              type="date"
              value={dataCFDI? dataCFDI.date.substring(0, 10) : startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>
          {view}
          <div className="col-span-1 sm:col-span-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-x-3">
            <div>
              <div className="flex items-center justify-between mr-5">
                <Label htmlFor="provider"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Emisor</p></Label>
                <div className="inline-flex items-center">
                  <Label>Nombre comercial?</Label>  
                  <div className="relative inline-block w-8 h-4 rounded-full cursor-pointer">
                    <input checked={isNoBusinessName} 
                      onClick={() => setIsNoBusinesName(!isNoBusinessName)} id="businessName" type="checkbox"
                      onChange={() => console.log('')}
                      className="absolute w-8 h-4 transition-colors duration-300 rounded-full 
                        appearance-none cursor-pointer peer bg-blue-gray-100 checked:bg-green-500 
                        peer-checked:border-green-500 peer-checked:before:bg-green-500
                        border border-slate-300" />
                    <label htmlFor="businessName"
                      className="before:content[''] absolute top-2/4 -left-1 h-5 w-5 -translate-y-2/4 cursor-pointer rounded-full border border-blue-gray-100 bg-white shadow-md transition-all duration-300 before:absolute before:top-2/4 before:left-2/4 before:block before:h-10 before:w-10 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-blue-gray-500 before:opacity-0 before:transition-opacity hover:before:opacity-10 peer-checked:translate-x-full peer-checked:border-green-500 peer-checked:before:bg-green-500">
                      <div className="inline-block p-5 rounded-full top-2/4 left-2/4 -translate-x-2/4 -translate-y-2/4"
                        data-ripple-dark="true"></div>
                    </label>
                  </div>
                </div>
              </div>
              {
                isNoBusinessName? (
                  viewProvider
                ): (
                  viewProviderSAT
                )
              }
            </div>
            {viewResponsible}
          </div>
          
        </div>

        {
          concept==="6691a5f9c14942310b52ac0e" && (
            <div className="grid grid-cols-3 gap-x-2 mt-5" >
              {optionsInvoices && (
                <div className=" col-span-2">
                  <Label htmlFor="CFDIrelations"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">CFDI&apos;s Relacionado</p></Label>
                  {/* <SelectReact index={0} opts={optionsInvoices} setValue={handleCfdirelations} /> */}
                  <SelectOptionReact opts={optionsInvoices} selOpt={optInvoice} setSelOpt={handleOptInvoice} 
                    setValue={handleCfdirelations} />
                </div>
              )}

              {/* <div>
                <Label htmlFor="typeCFDI"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Tipo de CFDI</p></Label>
                <SelectReact index={indexTypeCFDI} opts={types} setValue={handleTypeCfdiprov} />
              </div> */}
            </div>
          )
        }

        <div className="mt-5">
          <Label htmlFor="description"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Descripcion</p></Label>
          <textarea name="description"
            className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-white 
            focus:border-slate-700 outline-0 overflow-hidden resize-none"
            rows={4} 
            value={formik.values.description}
            onChange={formik.handleChange}
            onBlur={formik.handleChange}
          />
          {formik.touched.description && formik.errors.description ? (
            <div className="my-1 bg-red-100 border-l-4 font-light text-sm border-red-500 text-red-700 p-2">
              <p>{formik.errors.description}</p>
            </div>
          ) : null}
        </div>

        <div className="flex justify-center mt-8 space-x-5">
          <Button type="button" onClick={() => {
            if(refRequest.current){
              SaveData();
            }
            else{
              showToastMessageError('Ya hay una peticion en proceso..!');
            }
          }}>Guardar</Button>
        </div>
      </form> 
      {showProvider && <AddProvider token={token} setShowForm={setShowProvider} 
                            addProv={addProv}  />} 
    </div>
  )
}

export function SelectOptionReact({opts, setValue, disabled=false, setSelOpt, selOpt}: 
  {opts:Options[], setValue:Function, disabled?:boolean, 
    setSelOpt:(value: Options) => void, selOpt: Options| undefined}) {
  
  return(
    <Select
      value={selOpt}
      options={opts}
      onChange={(e:any) => {
        setSelOpt(e); 
        setValue(e.value)
      }} 
      className="w-full text-lg mt-2 text-gray-900  rounded-lg 
        bg-gray-50 focus:ring-blue-500 focus:border-slate-700 outline-0"
      styles={{
        control: (baseStyles, state) => ({
          ...baseStyles,
          height: '5px',
        }),
      }}
      isDisabled={disabled}
    />
  )
}