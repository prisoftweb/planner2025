"use client"
import { useTableStates } from "@/app/store/tableStates"
import { useEffect, forwardRef } from "react";

// export default function SearchInTable({placeH}: {placeH:string}){
  
//   const {search, updateSearch} = useTableStates();

//   useEffect(() => {
//     updateSearch('');
//   }, []);

//   return(
//     <div className="relative w-full max-w-md print:hidden">
//       <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none print:hidden">
//         <svg className="w-4 h-4 text-gray-500 dark:text-gray-400 print:hidden" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
//             <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
//         </svg>
//       </div>
//       <input 
//         type="search" 
//         id="default-search"
//         value={search}
//         autoFocus
//         onChange={(e) => updateSearch(e.target.value)} 
//         className="block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 
//           rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500
//           outline-0 outline-none 
//           dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 
//           dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 print:hidden" 
//         placeholder={placeH} required ></input>
//     </div>
//   )
// }

type SearchProps = {
  placeH:string
};

const SearchInTable = forwardRef<HTMLInputElement, SearchProps>(function Header( 
  { placeH }, ref ){
  
  const {search, updateSearch} = useTableStates();

  useEffect(() => {
    updateSearch('');
  }, []);

  return(
    <div className="relative w-full sm:max-w-md print:hidden">
      <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none print:hidden">
        <svg className="w-4 h-4 text-gray-500 dark:text-gray-400 print:hidden" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
        </svg>
      </div>
      <input 
        type="search" 
        id="default-search"
        ref={ref}
        value={search}
        autoFocus
        onChange={(e) => updateSearch(e.target.value)} 
        className="block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 
          rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500
          outline-0 outline-none 
          dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 
          dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 print:hidden" 
        placeholder={placeH} required ></input>
    </div>
  )
})

export default SearchInTable;