'use client'
import Label from "../Label"
import { useState, useEffect } from "react"
import SelectMultipleReact from "../SelectMultipleReact"
import { Options } from "@/interfaces/Common";
import Calendar, { DateObject } from "react-multi-date-picker";
import MultiRangeSlider from "multi-range-slider-react";
import { CurrencyFormatter } from "@/app/functions/Globals";
import { GiSettingsKnobs } from "react-icons/gi"
import { useOptionsQuotations } from "@/app/store/QuotationStates"
import TooltipCloseIcon from "../tooltipIcons/TooltipCloseIcon";

export default function FilteringQuatations({showForm, FilterData, maxAmount }: 
  {showForm:(value: boolean) => void, FilterData:Function, maxAmount:number }){

  const {optClients, optConditions} = useOptionsQuotations();
  
  const [clients, setClients] = useState<string[]>(['all']);
  const [conditions, setConditions] = useState<string[]>(['all']);
  const [optClientsState, setOptClientsState] = useState<Options[]>([{
    label: 'TODOS',
    value: 'all'
  }, ...optClients]);
  
  const [optConditionsState, setOptConditionsState] = useState<Options[]>([{
    label: 'TODOS',
    value: 'all'
  }, ...optConditions]);

  const [firstDate, setFirstDate] = useState<Date>(new Date('2024-03-11'));
  const [secondDate, setSecondDate] = useState<Date>(new Date('2024-07-11'));
  
  const [values, setValues] = useState([
    new DateObject().setDay(4).subtract(1, "month"),
    new DateObject().setDay(4).add(1, "month")
  ]);

  const handleValues = (dateValues: DateObject[]) => {
    setValues(dateValues);
    if(dateValues.length > 1){
      setFirstDate(new Date(dateValues[0].year, dateValues[0].month.number - 1, dateValues[0].day));
      setSecondDate(new Date(dateValues[1].year, dateValues[1].month.number - 1, dateValues[1].day));
    }else{
      if(values.length > 0){
        setFirstDate(new Date(values[0].year, values[0].month.number - 1, values[0].day));
      }
    }
  }

  const [minValue, set_minValue] = useState(0);
  const [maxValue, set_maxValue] = useState(maxAmount);

  const handleInput = (e:any) => {
    set_minValue(e.minValue);
    set_maxValue(e.maxValue);
  };

  useEffect(() => {
    FilterData(conditions, clients, minValue, maxValue, firstDate?.getTime(), secondDate?.getTime());
  }, [ minValue, maxValue, conditions, clients, firstDate, secondDate]);

  const handleCondition = (value:string[]) => {
    setConditions(value);
  }

  const handleClients = (value:string[]) => {
    setClients(value);
  }

  return(//top-16
    <>
      <div className="fixed inset-0 bg-black bg-opacity-40  z-40">
        <form className="z-10 fixed bg-white space-y-5 px-2 py-2 sm:py-5 sm:px-7 right-0 h-screen">
          <div className="flex justify-between p-2 rounded-md" style={{backgroundColor:'#F8FAFC', border:'0.5px solid #D3D3D3'}}>
            <div className="flex mt-2 items-center">
              <GiSettingsKnobs className="w-8 h-8 text-slate-600" />
              <div className="ml-3">
                <p className="text-xl">Filtrar Cotizaciones</p>
                <p className="text-gray-500 text-sm">Filtra cotizaciones por diferentes caracteristicas</p>
              </div>
            </div>
            <TooltipCloseIcon handleClose={showForm} />
          </div>
          
          <div className="">
            <Label htmlFor="status"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Status</p></Label>
            {optConditionsState.length > 0 && <SelectMultipleReact index={0} opts={optConditionsState} setValue={handleCondition} />}
          </div>
          <div className="">
            <Label htmlFor="clients"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Cliente</p></Label>
            {optClientsState.length > 0 && <SelectMultipleReact index={0} opts={optClientsState} setValue={handleClients} />}
          </div>
          <div className="pt-0">
            <Label htmlFor="amount"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Monto</p></Label>
            <MultiRangeSlider
              min={0}
              max={maxAmount}
              step={5}
              minValue={minValue}
              maxValue={maxValue}
              onInput={(e) => {
                handleInput(e);
              }}
              style={{border: 'none', boxShadow: 'none', padding: '15px 10px', 
                  backgroundColor: 'white', 'zIndex': '0'}}
              label='false'
              ruler='false'
              barLeftColor='red'
              barInnerColor='blue'
              barRightColor='green'
              thumbLeftColor='lime'
              thumbRightColor='lime'
            />
            <div className="flex justify-between">
              <p>{CurrencyFormatter({
                    currency: "MXN",
                    value: minValue
                  })}</p>
              <p>{CurrencyFormatter({
                    currency: "MXN",
                    value: maxValue
                  })}</p>
            </div>
          </div>
          <div>
            <Label htmlFor="date"><p className="after:content-['*'] after:ml-0.5 after:text-red-500">Fecha</p></Label>
            <Calendar
              className="w-full border border-slate-300 rounded-md px-2 py-1 my-2 bg-slate-100 
                focus:border-slate-700 outline-0"
              value={values}
              onChange={(e: any) => {
                handleValues(e);
              }}
              range
              numberOfMonths={2}
              showOtherDays
              style={{'padding': '10px', 'marginTop': '5px', 'borderRadius': '5px', 
                'height': '35px', 'width': '330px'}}
            /> 
          </div>
        </form>
      </div>
    </>
  )
}