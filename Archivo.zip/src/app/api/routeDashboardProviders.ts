import axios from "axios";

export async function getAllProvidersWithTradeLine(auth_token:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/providers/getAllProvidersWithTradeLine`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar proveedores con linea de credito';
  }
}

export async function getTotalCostPendingPaymentByProviderEstatusMIN(auth_token:string, dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getTotalCostPendingPaymentByProviderEstatusMIN/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total de costos pendientes por proveedor y estatus';
  }
}

export async function getTotalCostPendingPaymentByProvidersMIN(auth_token:string, dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getTotalCostPendingPaymentByProvidersMIN/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total de costos pendientes';
  }
}

export async function getAllCostsTOTALGroupByPROVIDERTRADELINE(auth_token:string, dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getAllCostsTOTALGroupByPROVIDERTRADELINE/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }, data: {
        "conditionCost": ["PAGADO", "DIFERIDO"]
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total de costos agrupados por proveedor con linea de credito';
  }
}

export async function getAllCostsGroupByPROVIDERWithoutTRADELINE(auth_token:string, tradeline:string, 
    dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getAllCostsGroupByPROVIDERWithoutTRADELINE/${tradeline}/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar costos agrupados por proveedor';
  }
}

export async function getTotalPayments(auth_token:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/payments/getAllPaymentsTOTAL`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total de pagos';
  }
}

export async function getTotalPendingPaymentsProvider(auth_token:string, dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getTotalCostPendingPaymentByProvidersTradelineMIN/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total pendiente de proveedor';
  }
}

export async function getTotalCostApplyPaymentByProvidersTradelineMIN(auth_token:string, dateStart:string, dateEnd:string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/costs/getTotalCostApplyPaymentByProvidersTradelineMIN/${dateStart}/${dateEnd}`;
  try {
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${auth_token}`
      }
    });
    if(res.status===200) return res.data.data.stats;
    return res.statusText;
  } catch (error) {
    if(axios.isAxiosError(error)){
      return error.message || error.response?.data.message;
    }
    return 'Error al consultar total de pago a proveedores';
  }
}