import { IInvoiceByProject, IInvoiceTable, IConceptInvoice } from "@/interfaces/Invoices";
import { ITableConceptsEstimate } from "@/interfaces/Estimate";

export function InvoiceDataToTableData(invoices:IInvoiceByProject[]){
  const table: IInvoiceTable[] = [];
  invoices.map((inv) => {
    table.push({
      amount: inv.cost.total,
      condition: inv.condition,
      estimate: inv.estimate.name,
      fecha: inv.date,
      folio: inv.folio,
      formpaid: inv.paymentWay,
      id: inv._id,
      methodpaid: inv.paymentMethod,
      usecfdi: inv.useCFDI,
      idEstimates:inv.estimate._id, 
      // charged: inv.lastpayment?.charged || 0,
      charged: inv.fullyCharged || 0,
      // charged: (inv.lastpayment?.unchargedbalanceamount >= 0 && inv.lastpayment?.unchargedbalanceamount <= 100? 
      //                         inv.cost.total: inv.cost.total - inv.lastpayment?.unchargedbalanceamount) || inv.cost.total,
      unchargedbalanceamount: inv.lastpayment?.unchargedbalanceamount || 0,
      previousBalance: inv.lastpayment?.previousbalanceamount || 0,
      // accountreceivablesCount: inv.accountreceivablesCount,
      accountreceivablesCount: inv.accountreceivables.length > 0? inv.accountreceivables[0].partialitynumber : 0,
      ischargedfull: inv.ischargedfull,
      uuid: inv.taxfolio
    })
  });

  return table;
}

export function ConceptsDataToConceptsTable(conepts:IConceptInvoice[]){
  const table: ITableConceptsEstimate[] = [];
  
  conepts.map((concept) => {
    table.push({
      id: concept.conceptEstimate._id,
      Cantidad: concept?.conceptEstimate?.quantity || 0,
      // Cantidad: 0,
      Clave: concept.conceptEstimate.code,
      Descripcion: concept.conceptEstimate.description,
      nombre: concept.conceptEstimate.name,
      // PU: concept.conceptEstimate?.priceConcepEstimate? (concept.conceptEstimate?.priceConcepEstimate?.cost? concept.conceptEstimate.priceConcepEstimate.cost: 0) : 0,
      PU: 0,
      // Importe: concept.conceptEstimate?.priceConcepEstimate? (concept.conceptEstimate?.amount? concept.conceptEstimate.amount: 0) : 0,
      Importe: 0,
      Unidad: (concept.conceptEstimate.unit?.name? concept.conceptEstimate.unit?.name: 'Sin unidad') || 'Sin unidad',
      idconcept: concept.conceptEstimate._id
    });
  });

  return table;
}