import { cookies } from "next/headers";
import { UsrBack } from "@/interfaces/User";
import Navigation from "@/components/navigation/Navigation";
import { ExpensesTable, Expense } from "@/interfaces/Expenses";
import { GetCostsMIN } from "../../api/routeCost";
import ContainerClient from "@/components/expenses/ContainerClient";
import { ExpenseDataToTableData } from "../../functions/CostsFunctions";
import ComponentError from "@/components/ComponentError";

export default async function Page() {
  
  const cookieStore = cookies();
  const token = cookieStore.get('token')?.value || '';
  const user: UsrBack = JSON.parse(cookieStore.get('user')?.value ||'');
  
  const role = user.rol?.name || '';
  const isViewReports = role.toLowerCase().includes('residente')? false: true;

  let expenses: Expense[] = await GetCostsMIN(token);
  
  if(typeof(expenses)=== 'string')
    return(
      <>
        <Navigation user={user} token={token} />
        {/* <div className="p-2 sm:p-3 md-p-5 lg:p-10">
          <h1 className="text-lg text-red-500 text-center">{expenses}</h1>
        </div> */}
        <ComponentError page="/expenses/history" message={expenses} />
      </>
    )

  const d = new Date();
  const dIni = new Date(d.getFullYear(), d.getMonth(), 1);

  const expensesFil= expenses.filter((e) => new Date(e.date).getTime() >= dIni.getTime() && new Date(e.date).getTime() <= d.getTime())

  const table: ExpensesTable[] = ExpenseDataToTableData(expensesFil);

  return(
    <>
      <Navigation user={user} token={token} />
      <ContainerClient data={table} expenses={expenses}
        token={token} user={user} isViewReports={isViewReports} 
        isHistory={true} company={user.profile} />
    </>
  )
}
